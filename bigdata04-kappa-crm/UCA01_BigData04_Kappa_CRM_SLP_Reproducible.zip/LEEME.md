# Big Data 04 | Expediente reproducible

La demostración procesa interacciones de un CRM turístico sintético mediante Tornado, Apache Kafka, MongoDB y un dashboard local. DuckDB y Parquet permiten comprobar los resultados sin poner en marcha la plataforma.

## Consultar la entrega

- [Guía para el profesor](LEEME_PROFESOR.pdf)
- [Google Colab verificado por el estudiante](https://colab.research.google.com/drive/1fS4TH9e0PiOsWHfEhIpZRNRcSa1rA10J?usp=sharing)
- [Cuaderno IPYNB](scripts/academic/bigdata04/UCA01_BigData04_Kappa_CRM_SLP.ipynb) y [HTML ejecutado autocontenido](scripts/academic/bigdata04/UCA01_BigData04_Kappa_CRM_SLP.html)
- [Instalación y reproducción](docs/INSTALACION_Y_REPRODUCCION.md)
- [Diccionario de datos](docs/DICCIONARIO_DE_DATOS.md)
- [Auditoría de entrega](docs/AUDITORIA_DE_ENTREGA.md) y [auditoría técnica original](docs/academic/uca-01-almacenamiento/BIGDATA04_AUDITORIA_FINAL.md)
- [Resultados originales](docs/academic/uca-01-almacenamiento/BIGDATA04_RESULTADOS_VERIFICADOS.md) y [mediciones agregadas](scripts/academic/bigdata04/evidence/measurements.json)

## Estructura

| Ruta | Contenido |
|---|---|
| `scripts/academic/bigdata04/` | Simulador, API, consumidor, contrato, catálogo, MongoDB, política, dashboard, Compose, SQL, utilidades, pruebas y cuaderno. |
| `.bigdata-private/bigdata04/exports/` | Los tres cortes experimentales originales y un corte de la nueva prueba de recuperación. Incluyen sus Parquet, una base DuckDB por corte, indicadores y manifiestos. |
| `.bigdata-private/bigdata04/replay/` | Corte de replay de la ejecución pequeña y su manifiesto. |
| `.bigdata-private/bigdata04/benchmarks/` | Medición original y prueba posterior del estudiante, identificadas por corrida. |
| `docs/` | Instrucciones, contrato, auditoría y contexto metodológico autorizado. |
| `INVENTARIO_SHA256.txt` | Huellas de los archivos de esta entrega, con rutas relativas a la extracción. |

Algunos exploradores ocultan carpetas cuyo nombre empieza con punto. El ZIP contiene `.bigdata-private/bigdata04/` porque las herramientas de ejecución usan esa ruta relativa. En esta distribución solo contiene cortes sintéticos y evidencia técnica seleccionada. Los boletines y bases de Big Data 01–03 permanecen en el repositorio de origen. El proveedor de Colab aplica los permisos del enlace compartido por el estudiante.
