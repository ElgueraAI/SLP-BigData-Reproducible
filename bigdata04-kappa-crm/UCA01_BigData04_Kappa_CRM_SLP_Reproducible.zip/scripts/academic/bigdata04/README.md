# Laboratorio Kappa del CRM turístico

El simulador y el tablero operan sobre un proyecto Docker llamado `slp-bigdata04`. El portal Astro aporta un catálogo de solo lectura. Todos los eventos, campañas, identidades y cupos de esta demostración son sintéticos.

## Arranque desde Windows

Desde la raíz del repositorio en PowerShell, con la distribución Ubuntu 24.04 y Docker Engine activos, el perfil offline reutiliza los servicios y bibliotecas académicas instalados. El contenedor monta Python, la biblioteca estándar y las dependencias de Ubuntu en solo lectura. `BIGDATA04_SITE_PACKAGES` permite indicar otra ruta compatible de Python 3.12, con ABI de Ubuntu 24.04 x86-64. Los volúmenes de datos y la red pertenecen al proyecto.

```powershell
$base = 'scripts/academic/bigdata04'
$stack = @('-d','Ubuntu-24.04','--exec','docker','compose','-f',"$base/compose.yaml",'-f',"$base/compose.wsl.yaml")
wsl.exe @stack up -d --no-build --pull never --wait --wait-timeout 150
wsl.exe @stack ps
Invoke-RestMethod http://127.0.0.1:18404/health
Start-Process http://127.0.0.1:18504/
```

Si WSL se cierra por inactividad en Windows, mantener una terminal Ubuntu abierta durante la exposición y repetir el arranque anterior. La reapertura conserva los offsets y los datos de ambos volúmenes. La corrida reproducida para el profesor se puede abrir directamente con `http://127.0.0.1:18504/?run_id=run-demo-visual`.

En otra computadora con Docker, el perfil portátil usa `docker compose -f scripts/academic/bigdata04/compose.yaml up --build -d`. Este camino requiere descargar las imágenes oficiales, paquetes de Ubuntu y dependencias Python de las versiones indicadas en el Dockerfile. Se necesita aprobación para esas descargas. El contexto histórico es opcional. El perfil offline lo monta en `/historical` como solo lectura. Se omite la opción `--historical` en un ensayo sin ese montaje. Para detener exclusivamente esta demo conservando ambos volúmenes, se usa `wsl.exe @stack stop`. MongoDB y Kafka solo son accesibles en la red de la demo.

## Reproducir

Cada benchmark requiere un id de corrida nuevo. El directorio privado conserva configuración, intentos, posiciones, muestras por servicio, cortes de pantalla en JSON, manifiestos y Parquet. Se debe ejecutar una sola carga de medición a la vez para atribuir los tiempos acumulados del consumidor. El siguiente bloque empieza con la escala pequeña, ensaya las fronteras y luego mide las otras escalas.

```powershell
$tag = Get-Date -Format yyyyMMddHHmmss
$p = @('-d','Ubuntu-24.04','--exec','/usr/bin/python3','-B')
wsl.exe @p "$base/benchmark.py" --offline --historical --run "run-$tag-small" --count 1000 --recovery
wsl.exe @p "$base/drills.py" --offline --run "run-$tag-small"
wsl.exe @p "$base/benchmark.py" --offline --historical --run "run-$tag-medium" --count 10000
wsl.exe @p "$base/benchmark.py" --offline --historical --run "run-$tag-large" --count 100000
wsl.exe @p "$base/evidence.py" --root .bigdata-private/bigdata04 --out ".bigdata-private/bigdata04/$tag-measurements.json" "run-$tag-small" "run-$tag-medium" "run-$tag-large"
wsl.exe @stack exec -T -e CRM_TEST_MONGO_URI=mongodb://mongo:27017 api python -m unittest -v test_pipeline test_reducer
```

El simulador permite limitar tasa, duración y volumen, fijar perfil, región, campaña y semilla, reconectar el productor y variar duplicados, retrasos, defectos, retornos y eliminaciones. Consulte `python simulator.py --help`. Una sesión selecciona los destinos con peso 3 para su interés principal y 1 para los demás, con igual oportunidad inicial para las dos campañas. La misma semilla y corrida fijan decisiones e identidades. El número pedido cuenta intentos HTTP individuales aun cuando viajen en lotes. Los porcentajes son probabilidades de inyección y su realización varía con la semilla. El reloj de negocio parte del 25 de noviembre de 2026 a las 12:00 UTC y avanza por acción creada. El sello de recepción usa el reloj real.

## Componentes y evidencias

| Archivo | Función |
|---|---|
| `catalog.mjs`, `catalog.json` | Regeneración con `node scripts/academic/bigdata04/catalog.mjs` sobre el compilado local y vocabularios de Astro. La instantánea preserva el SHA-256 del insumo. |
| `contracts.py`, `api.py` | Validación estricta y confirmación HTTP después del acuse. Cada elemento del lote tiene resultado propio. |
| `consumer.py`, `store.py`, `mongo.js` | Lectura de Kafka, escritura por identidad/posición, auditoría y offsets manuales. Cliente de Mongo mediante operaciones cerradas del shell oficial. |
| `reducer.py`, `policy.py` | Estados, atribución, cupo en plazas y revisiones A–D. Los eventos tardíos siguen en el corpus. |
| `dashboard.py`, `dashboard.html` | Consulta del corte publicado, latencia de refresco e historial de decisiones en cinco vistas. |
| `export.py`, `queries.sql` | Parquet comprimido, DuckDB y verificación de manifiestos. Se puede repetir `python export.py --verify /results/exports/<corrida>/<corte>/manifest.json` en el contenedor. |
| `benchmark.py`, `lag.py`, `drills.py`, `showcase.py` | Medición del sistema real, caída antes de commit, replay aislado y demostración de políticas. |
| `evidence.py`, `make_notebook.py` | Conciliación de mediciones y construcción del cuaderno portable con agregados. |

La retención configurada es de siete días y 256 MiB por partición, con réplica uno. La implementación dedica tres particiones tanto al tópico de entrada como al de cuarentena y conserva sus offsets por separado. El diseño inicial proponía una partición para la cuarentena. La operación en un único host permite verificar reinicios con disco conservado. La prueba de pérdida física del host queda fuera del alcance medido.

Los históricos INAH y DataTur conservan sus propios datos, sus unidades y sus fechas. Los controles de política se escriben directamente como revisiones inmutables del laboratorio. El portal no tiene adaptador de CRM activo. El cliente de la API de demostración carece de autenticación de usuario. Se mantienen los puertos en loopback y se reservan para este equipo.

## Cuaderno y contexto temporal

El cuaderno `UCA01_BigData04_Kappa_CRM_SLP.ipynb` incluye los agregados de las tres ejecuciones. Al ejecutarse en Colab o Jupyter necesita pandas, Matplotlib y, para la variante con Parquet, PyArrow. Para sustituir el expediente, coloque el archivo producido por `evidence.py` con nombre `measurements.json` en la carpeta de ejecución. La celda opcional también verifica los archivos de un corte en `export/`. Se puede reconstruir el cuaderno con `python make_notebook.py evidence/measurements.json` en un entorno con nbformat y ejecutarlo en un kernel nuevo.

El reloj del simulador vuelve al mismo origen en cada corrida. El watermark del consumidor abarca toda la partición durante la vida del grupo. Por ello, los eventos tardíos **observados** y las demoras **inyectadas** miden fenómenos diferentes. Los estados de ruta y favorito se resuelven por secuencia de actor y los indicadores de campaña por tiempo de evento.
