"""Local HTTP ingestion. A result becomes accepted only on a Kafka delivery callback."""

import asyncio
import logging
import os
import threading

from confluent_kafka import Producer
from tornado.web import Application, RequestHandler

from contracts import (
    EVENT_TOPIC, MAX_BATCH, MAX_BODY_BYTES, QUARANTINE_TOPIC, ContractError,
    Validator, decode_json, json_bytes, load_catalog, partition_key, rejection, utc_text,
)


def kafka_producer_config(bootstrap):
    return {
        "bootstrap.servers": bootstrap,
        "enable.idempotence": True,
        "acks": "all",
        "delivery.timeout.ms": 10_000,
        "request.timeout.ms": 4_000,
        "retry.backoff.ms": 200,
        "retry.backoff.max.ms": 1_000,
        "allow.auto.create.topics": False,
        "linger.ms": 5,
    }


class KafkaPublisher:
    def __init__(self, bootstrap):
        self.producer = Producer(kafka_producer_config(bootstrap))
        self.stopped = threading.Event()
        self.thread = threading.Thread(target=self._poll, name="kafka-producer-poll", daemon=True)
        self.thread.start()

    def _poll(self):
        while not self.stopped.is_set():
            self.producer.poll(0.1)

    def close(self):
        self.stopped.set()
        self.thread.join(timeout=1)
        self.producer.flush(timeout=2)

    def health(self):
        try:
            metadata = self.producer.list_topics(timeout=1)
            return all(
                topic in metadata.topics
                and metadata.topics[topic].error is None
                and bool(metadata.topics[topic].partitions)
                and all(partition.leader >= 0 for partition in metadata.topics[topic].partitions.values())
                for topic in (EVENT_TOPIC, QUARANTINE_TOPIC)
            )
        except Exception:
            return False

    async def publish(self, records):
        loop = asyncio.get_running_loop()
        futures = []

        def finish(future, value):
            if not future.done():
                future.set_result(value)

        def delivered(future, error, message):
            ack = None if error else {
                "topic": message.topic(), "partition": message.partition(), "offset": message.offset(),
            }
            loop.call_soon_threadsafe(finish, future, (ack, "broker_delivery_failed" if error else None))

        for topic, key, value in records:
            future = loop.create_future()
            futures.append(future)
            try:
                self.producer.produce(
                    topic, key=key, value=json_bytes(value),
                    on_delivery=lambda error, message, future=future: delivered(future, error, message),
                )
            except BufferError:
                finish(future, (None, "broker_queue_full"))
            except Exception:
                finish(future, (None, "broker_unavailable"))
        if not futures:
            return []
        _, pending = await asyncio.wait(futures, timeout=11)
        for future in pending:
            finish(future, (None, "broker_timeout"))
        return [future.result() for future in futures]


class LocalHandler(RequestHandler):
    def initialize(self, publisher, validator):
        self.publisher = publisher
        self.validator = validator

    def set_default_headers(self):
        self.set_header("Cache-Control", "no-store")
        self.set_header("X-Content-Type-Options", "nosniff")

    def write_error(self, status_code, **kwargs):
        self.finish({"status": "error", "reason": "http_error"})


class HealthHandler(LocalHandler):
    async def get(self):
        ready = await asyncio.to_thread(self.publisher.health)
        self.set_status(200 if ready else 503)
        self.finish({"status": "ok" if ready else "degraded", "broker_available": ready})


class EventsHandler(LocalHandler):
    async def post(self):
        items, request_error = self._body()
        records, results = [], []
        for item in items:
            try:
                if request_error:
                    raise ContractError(request_error)
                event = self.validator.event(item)
            except ContractError as exc:
                metadata = rejection(exc.reason, "api", item)
                records.append((QUARANTINE_TOPIC, b"api", metadata))
                results.append({"status": "rejected", "reason": exc.reason})
            else:
                event["received_at"] = utc_text()
                records.append((EVENT_TOPIC, partition_key(event), event))
                results.append({"status": "accepted", "event_id": event["event_id"]})

        acknowledgments = await self.publisher.publish(records)
        for index, (ack, error) in enumerate(acknowledgments):
            if error:
                results[index] = {"status": "retry", "reason": error}
            elif results[index]["status"] == "accepted":
                results[index].update(ack)

        counts = {state: sum(item["status"] == state for item in results) for state in ("accepted", "rejected", "retry")}
        if counts["retry"]:
            status = 503
        elif counts["accepted"] and counts["rejected"]:
            status = 207
        elif counts["accepted"]:
            status = 202
        else:
            status = {
                "body_size": 413, "batch_size": 413, "content_type": 415,
            }.get(request_error, 400)
        self.set_status(status)
        self.finish({"results": results, **counts})

    def _body(self):
        if len(self.request.body) > MAX_BODY_BYTES:
            return [None], "body_size"
        content_type = self.request.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
        if content_type != "application/json":
            return [None], "content_type"
        try:
            body = decode_json(self.request.body)
        except ContractError as exc:
            return [None], exc.reason
        if type(body) is list:
            if not 1 <= len(body) <= MAX_BATCH:
                return [None], "batch_size"
            return body, None
        return [body], None


def make_application(publisher, validator):
    arguments = {"publisher": publisher, "validator": validator}
    return Application([
        (r"/health", HealthHandler, arguments),
        (r"/events", EventsHandler, arguments),
    ], log_function=lambda _handler: None, compress_response=False)


async def main():
    logging.getLogger("tornado.access").disabled = True
    validator = Validator(load_catalog(os.getenv("CRM_CATALOG")))
    publisher = KafkaPublisher(os.getenv("KAFKA_BOOTSTRAP", "broker:9092"))
    app = make_application(publisher, validator)
    try:
        app.listen(
            int(os.getenv("PORT", "8080")), address=os.getenv("API_BIND", "0.0.0.0"),
            max_body_size=MAX_BODY_BYTES * 2, xheaders=False,
        )
        await asyncio.Event().wait()
    finally:
        publisher.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
