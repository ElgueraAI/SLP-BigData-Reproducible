"""Validate completed CRM cuts without importing the production reducer."""

import argparse
import hashlib
import json
from pathlib import Path

import duckdb
import pyarrow.parquet as pq


CTR_SQL = """
WITH originals AS (
    SELECT *, count(*) OVER (PARTITION BY impression_id) AS exposures
    FROM events WHERE event_type IN ('campaign_impression', 'destination_impression')
), exposures AS (
    SELECT *, visible_fraction >= .50 AND visible_ms >= 1000 AS visible
    FROM originals WHERE exposures = 1
), attributed AS (
    SELECT c.*, i.event_id AS exposure_event_id,
           CASE WHEN i.event_id IS NOT NULL THEN i.event_time ELSE c.event_time END AS period_time,
           CASE WHEN i.event_id IS NOT NULL THEN i.profile_id ELSE c.profile_id END AS attribution_profile
    FROM events c LEFT JOIN exposures i
      ON i.impression_id = c.impression_id AND i.visible
     AND split_part(i.event_type, '_', 1) = split_part(c.event_type, '_', 1)
     AND i.session_id = c.session_id AND i.demo_actor_id = c.demo_actor_id
     AND i.destination_id IS NOT DISTINCT FROM c.destination_id
     AND i.campaign_id IS NOT DISTINCT FROM c.campaign_id
     AND i.event_time::TIMESTAMPTZ <= c.event_time::TIMESTAMPTZ
    WHERE c.event_type IN ('campaign_click', 'destination_click')
), observations AS (
    SELECT split_part(event_type, '_', 1) AS family, substr(event_time, 1, 10) AS day_utc,
           coalesce(campaign_id, '') AS campaign_id, profile_id, coalesce(destination_id, '') AS destination_id,
           visible::INT AS eligible, NULL::VARCHAR AS clicked_id, 0 AS clicked
    FROM exposures
    UNION ALL
    SELECT split_part(event_type, '_', 1), substr(period_time, 1, 10), coalesce(campaign_id, ''),
           attribution_profile, coalesce(destination_id, ''), 0, exposure_event_id, 1
    FROM attributed
)
SELECT family, day_utc, campaign_id, profile_id, destination_id,
       sum(eligible)::BIGINT AS eligible_impressions,
       count(DISTINCT clicked_id) AS clicked_impressions,
       count(clicked_id) AS eligible_click_actions, sum(clicked)::BIGINT AS click_actions,
       count(DISTINCT clicked_id) * 100.0 / nullif(sum(eligible), 0) AS ctr_pct
FROM observations GROUP BY ALL
"""


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def logical_hash(value):
    normalized = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def file_hash(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def assert_equal(db, expected, actual):
    differences = db.execute(f"""
        SELECT count(*) FROM (
            ({expected} EXCEPT ALL {actual}) UNION ALL ({actual} EXCEPT ALL {expected})
        )
    """).fetchone()[0]
    assert not differences, f"{differences} diferencias entre {expected[:80]} y {actual[:80]}"


def sql_oracles(db, metrics):
    db.execute(f"CREATE TEMP TABLE independent_ctr AS {CTR_SQL}")
    columns = "family, day_utc, campaign_id, profile_id, destination_id, eligible_impressions, clicked_impressions, eligible_click_actions, click_actions, ctr_pct"
    assert_equal(db, f"SELECT {columns} FROM independent_ctr", f"SELECT {columns} FROM ctr_cells")
    totals = "eligible_impressions, clicked_impressions, eligible_click_actions, click_actions"
    sums = ", ".join(f"sum({item})" for item in totals.split(", "))
    rate = "100.0 * sum(clicked_impressions) / nullif(sum(eligible_impressions), 0)"
    daily_keys = "family, day_utc, campaign_id"
    assert_equal(db, f"SELECT {daily_keys}, {sums}, {rate} FROM independent_ctr GROUP BY {daily_keys}",
                 f"SELECT {daily_keys}, {totals}, ctr_pct FROM ctr_daily")
    assert_equal(db, f"""SELECT family, campaign_id, {sums}, {rate} FROM (
          SELECT family, campaign_id, {totals} FROM independent_ctr
          UNION ALL SELECT * FROM (VALUES ('campaign', 'camp-agua', 0, 0, 0, 0),
            ('campaign', 'camp-cultura', 0, 0, 0, 0), ('destination', '', 0, 0, 0, 0))
        ) GROUP BY family, campaign_id""", f"SELECT family, campaign_id, {totals}, ctr_pct FROM campaign_metrics")
    counts = {}
    for group, family, table in (("routes", "destination", "route_state"), ("favorites", "favorite", "favorite_state")):
        add, remove = f"{family}_added", f"{family}_removed"
        keys = "demo_actor_id, route_id, destination_id" if family == "destination" else "demo_actor_id, destination_id"
        expected = f"""SELECT {keys}, event_id, event_sequence, event_time, event_type = '{add}' AS active
            FROM events WHERE event_type IN ('{add}', '{remove}')
            QUALIFY row_number() OVER (PARTITION BY {keys} ORDER BY event_sequence DESC, event_id DESC) = 1"""
        assert_equal(db, expected,
                     f"SELECT {keys}, event_id, event_sequence, event_time, active FROM {table}")
        adds, removes = db.execute("SELECT count_if(event_type = ?), count_if(event_type = ?) FROM events", [add, remove]).fetchone()
        active, rows = db.execute(f"SELECT count(*) FILTER (WHERE active), count(*) FROM ({expected})").fetchone()
        counts[group] = {"adds": adds, "removes": removes, "active": active}
        assert counts[group] == metrics["state_totals"][group]
        counts[group]["inactive"] = rows - active
    recommendation_counts = db.execute("""SELECT count_if(event_type = 'recommendation_seen'),
        sum(len(place_ids)) FILTER (WHERE event_type = 'recommendation_seen'),
        count_if(event_type = 'recommendation_added') FROM events""").fetchone()
    assert list(recommendation_counts) == [metrics["recommendations"][key] for key in ("lists", "items_shown", "saved_actions")]
    return counts


def audit_cut(manifest_path, catalog):
    manifest = read_json(manifest_path)
    parent = manifest_path.parent
    identifiers = {key: manifest[key] for key in ("simulation_run_id", "cut_id")}
    tables, files = manifest["tables"], manifest["files"]
    assert set(files) == {row["file"] for row in tables.values()} | {"crm.duckdb", "indicators.json"}
    for name, info in files.items():
        assert (parent / name).stat().st_size == info["bytes"], name
        assert file_hash(parent / name) == info["sha256"], name
    indicators = read_json(parent / "indicators.json")
    assert all(indicators[key] == value for key, value in identifiers.items())
    assert indicators["positions"] == manifest["positions"]
    assert indicators["label"] == manifest["label"] == "ENTORNO ACADÉMICO — DATOS SINTÉTICOS"
    metrics = indicators["metrics"]
    db = duckdb.connect(config={"threads": 2, "TimeZone": "UTC"})
    connection_path = str(parent / "crm.duckdb").replace("'", "''")
    db.execute(f"ATTACH '{connection_path}' AS persisted (READ_ONLY)")
    logical_rows = {}
    for name, info in tables.items():
        path = parent / info["file"]
        parquet = pq.ParquetFile(path)
        table = parquet.read()
        assert table.num_rows == info["rows"], name
        actual_schema = {field.name: str(field.type).replace("list<element:", "list<item:") for field in table.schema}
        assert actual_schema == info["schema"], name
        assert table.schema.metadata[b"provenance"] == b"SIMULADO", name
        for key, value in identifiers.items():
            assert not table.num_rows or table[key].unique().to_pylist() == [value], (name, key)
        fields = ["cut_id"] if name in {"events", "controls"} else ["cut_id", "simulation_run_id"]
        rows = table.drop(fields).to_pylist()
        if name == "events":
            rows = [{key: value for key, value in row.items() if value is not None} for row in rows]
        assert logical_hash(rows) == info["logical_sha256"], name
        logical_rows[name] = rows
        db.read_parquet(str(path)).create_view(name)
        assert_equal(db, f'SELECT * FROM "{name}"', f'SELECT * FROM persisted."{name}"')
    assert manifest["hashes"] == {
        "catalog": logical_hash(catalog), "corpus": logical_hash(logical_rows.pop("events")),
        "controls": logical_hash(logical_rows["controls"]),
        "results": logical_hash({"tables": logical_rows, "summary": metrics}),
    }
    events, unique, valid = db.execute("""SELECT count(*), count(DISTINCT event_id), count(*) FILTER (
        WHERE synthetic IS TRUE AND source = 'simulator' AND schema_version = 1
          AND event_time IS NOT NULL AND event_sequence IS NOT NULL AND session_id IS NOT NULL
          AND profile_id IN (SELECT profile_id FROM profiles) AND demo_actor_id IS NOT NULL
          AND (destination_id IS NULL OR destination_id IN (SELECT destination_id FROM destinations))
    ) FROM events""").fetchone()
    assert events == unique == valid
    assert db.execute("SELECT count(*) FROM decisions WHERE automatic_increase IS DISTINCT FROM false").fetchone() == (0,)
    policy = db.execute("""SELECT trigger_case, trigger_revision, status, reason, capacity, reservations, places_available
        FROM decision_history ORDER BY trigger_case""").fetchall()
    if policy:
        assert policy == [("A", 1, "pausa", "cupo_insuficiente", 10, 10, 0),
                          ("B", 1, "candidato", "requiere_validacion_humana", 10, 4, 6),
                          ("D", 2, "pausa", "cupo_insuficiente", 4, 4, 0)]
    policy_c = db.execute("""SELECT count(*) FROM decisions WHERE "case" = 'C' AND status = 'sin_datos'
        AND reason = 'sin_revision_operativa' AND capacity IS NULL AND reservations IS NULL""").fetchone()[0]
    assert policy_c == 50
    states = sql_oracles(db, metrics)
    db.close()
    return {"manifest": str(manifest_path), **identifiers, "events": events, "tables": len(tables),
            "artifacts": len(files), "hashes": manifest["hashes"], "states": states,
            "campaigns": [row for row in logical_rows["campaign_metrics"] if row["family"] == "campaign"],
            "policy_history": policy, "without_controls": policy_c}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifests", nargs="+", type=Path)
    options = parser.parse_args()
    catalog = read_json(Path(__file__).with_name("catalog.json"))
    print(json.dumps({"duckdb": duckdb.__version__, "cuts": [audit_cut(path, catalog) for path in options.manifests]},
                     indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
