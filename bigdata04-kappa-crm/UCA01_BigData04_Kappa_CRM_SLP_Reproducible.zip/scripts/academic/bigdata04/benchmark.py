"""Orquestador finito del ensayo. Se ejecuta en el host Docker (WSL o Linux)."""
import argparse
import datetime as dt
import json
import os
import platform
import subprocess
import threading
import time
import urllib.parse
import urllib.request
from pathlib import Path
import simulator

HERE = Path(__file__).resolve().parent
RESULTS = HERE.parents[2] / ".bigdata-private" / "bigdata04"


def command(args, timeout=180):
    proc = subprocess.run(args, cwd=HERE, text=True, capture_output=True, timeout=timeout)
    if proc.returncode:
        raise RuntimeError(f"{args}: {proc.stderr[-1800:]} {proc.stdout[-600:]}")
    return proc.stdout.strip()


def write(path, data):
    path.parent.mkdir(exist_ok=True, parents=True)
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(data, indent=2, ensure_ascii=False),encoding="utf-8")
    temp.replace(path)


def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()


class Stack:
    def __init__(self, offline):
        self.cli = ["docker","compose","-f","compose.yaml"]
        if offline:
            self.cli += ["-f","compose.wsl.yaml"]

    def compose(self, *args, timeout=180):
        return command(self.cli + list(args), timeout)

    def python(self, *args, timeout=180):
        return self.compose("exec","-T","api","python",*args,timeout=timeout)

    def totals(self):
        query = ("const d=db.getSiblingDB('slp_bigdata04_demo');"
                 "print(JSON.stringify({totals:d.consumer_state.findOne({_id:'input'})?.totals||{},"
                 "storage_bytes:d.stats().storageSize,index_bytes:d.stats().indexSize}))")
        return json.loads(self.compose("exec","-T","mongo","mongosh","--quiet","--eval",query))

    def drain(self, timeout=600):
        start = time.monotonic()
        while time.monotonic() - start < timeout:
            states = json.loads(self.python("lag.py"))
            if not sum(row["lag"] for row in states.values()):
                return states
            time.sleep(0.6)
        raise TimeoutError("El grupo no alcanzó los offsets publicados.")


def sample_containers(stop, samples, errors):
    # Cgroup v2 reports bytes for the whole container (including the Mongo shell).
    names = ["api","consumer","dashboard","broker","mongo"]
    while not stop.is_set():
        for service in names:
            try:
                data = command(["docker","exec",f"slp-bigdata04-{service}-1","sh","-c",
                                "cat /sys/fs/cgroup/memory.current /sys/fs/cgroup/cpu.stat"],12).splitlines()
                usage = int(next(row.split()[1] for row in data if row.startswith("usage_usec ")))
                samples.append({"service":service,"epoch":time.time(),"bytes":int(data[0]),"cpu_us":usage})
            except (RuntimeError, StopIteration, subprocess.TimeoutExpired) as err:
                errors.append({"service":service, "type":type(err).__name__})
        stop.wait(1)


def summarize_samples(samples):
    result = {}
    for service in sorted({s["service"] for s in samples}):
        rows = [s for s in samples if s["service"] == service]
        pairs = [(b["cpu_us"]-a["cpu_us"])/1e6 for a,b in zip(rows,rows[1:]) if b["cpu_us"]>=a["cpu_us"]]
        result[service] = {"sample_count":len(rows),"peak_sampled_bytes":max(s["bytes"] for s in rows),
                           "cpu_observed_s":sum(pairs) if pairs else None}
    return result


def snapshot(run, accepted, changed=False):
    start = time.perf_counter()
    url = "http://127.0.0.1:18504/api/snapshot?"+urllib.parse.urlencode({"run_id":run})
    while time.perf_counter() - start < 240:
        tick = time.perf_counter()
        with urllib.request.urlopen(url, timeout=30) as r:
            data = json.load(r)
        http_s = time.perf_counter()-tick
        monitor = data.get("monitor",{})
        if (data.get("status") == "ready" and monitor.get("counts",{}).get("deliveries") == accepted
                and (not changed or any(p.get("case") == "D" for p in data.get("policies",[])))):
            return {"at":utc(),"http_s":http_s,"wait_s":time.perf_counter()-start,"body":data}
        time.sleep(1)
    raise TimeoutError(f"El tablero no publicó el corte esperado para {run}")


def benchmark(args):
    path = RESULTS / "benchmarks" / args.run
    path.mkdir(parents=True,exist_ok=False)
    stack = Stack(args.offline)
    initial = stack.drain()
    before = stack.totals()
    write(path/"environment.json",{"at":utc(),"platform":platform.platform(),"cpu_logical":os.cpu_count(),
          "cpu_model":next((line.split(':',1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines()
                            if line.startswith("model name")),None),
          "memory":Path('/proc/meminfo').read_text().splitlines()[0],"docker":command(["docker","version","--format","{{.Server.Version}}"]),
          "compose":stack.compose("version"),"services":stack.compose("ps","--format","json"),
          "images":command(["docker","image","inspect","apache/kafka:4.3.1","mongo:8.0.16","--format","{{json .RepoDigests}}"]),
          "initial_positions":initial,"database_before":before,"arguments":vars(args)})
    stack.python("policy.py","--run-id",args.run,"--stage","initial")
    recovery = {}
    samples,errors = [],[]
    shutdown = threading.Event()
    thread = threading.Thread(target=sample_containers,args=(shutdown,samples,errors),daemon=True)
    thread.start()
    start = time.perf_counter()
    def progress(stats):
        if args.recovery and not recovery and stats["attempts"] >= args.count // 3:
            recovery["before"] = stack.drain()
            write(path/"dashboard-before.json",snapshot(args.run,stats["accepted"]))
            stack.compose("stop","-t","8","consumer")
            recovery["stop_at"] = utc()
    try:
        try:
            pub = simulator.publish(args,progress)
            write(path/"publication.json",pub)
        finally:
            if "stop_at" in recovery:
                recovery["during"] = json.loads(stack.python("lag.py"))
                recovery["restart_at"] = utc()
                restart = time.perf_counter()
                stack.compose("start","consumer")
        final = stack.drain()
        end = time.perf_counter()
        if "restart_at" in recovery:
            recovery.update(seconds=end-restart, after=final)
    finally:
        shutdown.set()
        thread.join(65)
        write(path/"resources.json",{"samples":samples,"unavailable":errors})
    write(path/"flow.json",{"seconds":end-start,"end_positions":final,"recovery":recovery})
    after = stack.totals()
    stack.python("policy.py","--run-id",args.run,"--stage","change")
    write(path/"dashboard-after.json",snapshot(args.run,pub["accepted"],changed=True))
    export_at = utc()
    cmd = ["export.py","--run-id",args.run,"--output","/results/exports","--seed",str(args.seed),"--as-of",export_at]
    if args.historical:
        cmd += ["--historical-db","/historical/campaign.duckdb"]
    tick = time.perf_counter()
    export_log=stack.python(*cmd,timeout=600)
    export_s = time.perf_counter()-tick
    manifest = max((RESULTS/"exports"/args.run).glob("*/manifest.json"),key=lambda p:p.stat().st_mtime_ns)
    result = {"run":args.run,"completed_at":utc(),"publication":pub,"flow_s":end-start,
              "export_s":export_s,"export_message":export_log[-2048:],"manifest":str(manifest.relative_to(RESULTS)),
              "recovery":recovery,"resources":summarize_samples(samples),"final_lag":sum(v["lag"] for v in final.values()),
              "database_after":after,"phase_delta":{k:v-before["totals"].get(k,0) for k,v in after["totals"].items()}}
    write(path/"result.json",result)
    print(json.dumps(result,ensure_ascii=False),flush=True)


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    simulator.arguments(parser)
    parser.add_argument("--offline",action="store_true")
    parser.add_argument("--historical",action="store_true")
    parser.add_argument("--recovery",action="store_true")
    benchmark(parser.parse_args())
