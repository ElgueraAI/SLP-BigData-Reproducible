import fs from 'node:fs';
import { createHash } from 'node:crypto';

const root = new URL('../../../', import.meta.url);
const source = fs.readFileSync(new URL('dist/data/intel.json', root));
const segments = fs.readFileSync(new URL('src/lib/intel/segments.ts', root), 'utf8');
const taxonomy = fs.readFileSync(new URL('src/lib/intel/taxonomy.ts', root), 'utf8');
const profiles = [...segments.matchAll(/\{ id: '([^']+)', name:/g)].map(match => match[1]);
const labels = taxonomy.split('export const INTEREST_LABEL')[1].split('};')[0];
const interests = [...labels.matchAll(/^  '?([\w-]+)'?: '/gm)].map(match => match[1]);
const destinations = JSON.parse(source).places.filter(place => place.kind === 'destination'
  && place.route_id && ['altiplano', 'centro', 'huasteca', 'zona-media'].includes(place.region))
  .map(({ id, name, region, interests }) => ({ id, name, region, interests }))
  .sort((a, b) => a.id.localeCompare(b.id, 'en'));
if (profiles.length !== 8 || interests.length !== 12 || !destinations.length
    || new Set(destinations.map(place => place.id)).size !== destinations.length
    || destinations.some(place => place.interests.some(interest => !interests.includes(interest)))) {
  throw new Error('Revisar cambios en el contrato del catálogo del portal.');
}
const catalog = { schema_version: 1, source: 'dist/data/intel.json', source_sha256: createHash('sha256').update(source).digest('hex'),
  destinations, profiles, interests, campaigns: ['camp-agua', 'camp-cultura'] };
fs.writeFileSync(new URL('catalog.json', import.meta.url), JSON.stringify(catalog, null, 2) + '\n');
