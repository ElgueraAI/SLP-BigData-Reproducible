// Windows integration drill. It briefly stops only the named API in the isolated WSL Compose project.
import { execFileSync } from 'node:child_process';
import { mkdir, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright-core';

const run = process.argv[2];
if (process.argv[3] !== '--test-api-outage' || !/^run-[a-z0-9-]{1,60}$/.test(run ?? '')) {
  throw new Error('Uso: node check_dashboard.mjs run-… --test-api-outage');
}
const project = fileURLToPath(new URL('../../../', import.meta.url));
const output = new URL('../../../.bigdata-private/bigdata04/dashboard-qa/', import.meta.url);
const wsl = ['-d', 'Ubuntu-24.04', '--exec', 'docker', 'compose', '-f', 'scripts/academic/bigdata04/compose.yaml',
  '-f', 'scripts/academic/bigdata04/compose.wsl.yaml'];
function service(action) {
  execFileSync('wsl.exe', [...wsl, action, 'api'], { cwd: project, windowsHide: true, timeout: 45000 });
}
const browser = await chromium.launch({ executablePath: process.env.BIGDATA04_BROWSER
  || 'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe', args: ['--disable-background-networking'] });
const page = await browser.newPage();
const evidence = [];
async function observe(label, expected) {
  await page.waitForFunction(text => document.querySelector('#services')?.textContent.includes(text), expected, { timeout: 60000 });
  const body = await (await page.request.get('http://127.0.0.1:18504/api/snapshot?run_id='+run)).json();
  evidence.push({ phase: label, at: new Date().toISOString(), rendered: await page.locator('#services').innerText(),
    cut: body.cut_id, canonical: body.monitor.canonical_events, services: body.services });
}
try {
  await page.goto('http://127.0.0.1:18504/?run_id='+run);
  await observe('antes', 'API · activo');
  try {
    service('stop');
    await observe('API detenida', 'API · degradado');
  } finally {
    service('start');
  }
  await observe('recuperada', 'API · activo');
  if (new Set(evidence.map(row => row.canonical)).size !== 1 || evidence[1].services.broker !== null) {
    throw new Error('La pantalla no conservó el corte o atribuyó salud al broker sin señal.');
  }
  await mkdir(output, {recursive:true});
  await writeFile(new URL('api-outage.json',output), JSON.stringify(evidence,null,2));
  console.log(JSON.stringify(evidence));
} finally {
  await browser.close();
}
