"""Execute in two new kernels, standalone and with a verified local Parquet export."""
import argparse
import json
import tempfile
from pathlib import Path
import nbformat
from nbclient import NotebookClient


def execute(source, directory):
    notebook=nbformat.read(source,as_version=4)
    client=NotebookClient(notebook,timeout=90,kernel_name="python3")
    client.execute(cwd=str(directory))
    nbformat.validate(notebook)
    code=[cell for cell in notebook.cells if cell.cell_type=="code"]
    figures=sum("image/png" in output.get("data",{}) for cell in code for output in cell.outputs)
    if any(cell.execution_count is None for cell in code) or figures!=8:
        raise RuntimeError(f"Cuaderno incompleto: {figures} gráficas renderizadas.")
    return notebook,{"code_cells":len(code),"figures":figures,"markdown_cells":len(notebook.cells)-len(code)}


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("export",type=Path)
    parser.add_argument("report",type=Path)
    args=parser.parse_args()
    source=Path(__file__).with_name("UCA01_BigData04_Kappa_CRM_SLP.ipynb")
    with tempfile.TemporaryDirectory() as tmp:
        work=Path(tmp)
        standalone,first=execute(source,work)
        (work/"export").symlink_to(args.export.resolve(),target_is_directory=True)
        _,second=execute(source,work)
    nbformat.write(standalone,source)
    args.report.write_text(json.dumps({"standalone":first,"with_parquet":second,"kernel":"python3","runtime":"WSL2",
                                       "export":args.export.name},indent=2),encoding="utf-8")
