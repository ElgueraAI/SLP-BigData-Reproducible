"""Read Kafka in batches and commit offsets only after durable effects and quarantine."""

import os
import signal
import threading
import time

from confluent_kafka import Consumer, KafkaError, KafkaException, Producer, TopicPartition

from api import kafka_producer_config
from contracts import (
    EVENT_TOPIC, MAX_EVENT_BYTES, QUARANTINE_TOPIC, REASONS, ContractError, Validator, decode_json,
    fingerprint, is_run_id, json_bytes, load_catalog, parse_utc, partition_key, rejection, utc_text,
)
from store import Store, StoreError


class StreamError(RuntimeError):
    pass


class RetentionGap(StreamError):
    pass


def milliseconds(since):
    return round((time.monotonic() - since) * 1000, 3)


def message_position(message):
    return {"topic": message.topic(), "partition": message.partition(), "offset": message.offset()}


def validate_broker_message(message, validator):
    position = message_position(message)
    payload = None
    try:
        raw = message.value()
        if raw is None or len(raw) > MAX_EVENT_BYTES + 100:
            raise ContractError("event_size")
        payload = decode_json(raw)
        event = validator.event(payload, broker=True)
        if message.key() != partition_key(event):
            raise ContractError("invalid_key")
    except ContractError as exc:
        return {**position, "quarantine": rejection(exc.reason, "consumer", payload, position)}
    return {**position, "event": event, "fingerprint": fingerprint(event)}


def api_quarantine_message(message):
    raw = message.value()
    if raw is None or len(raw) > 1024 or message.key() != b"api":
        return None
    try:
        value = decode_json(raw)
        if type(value) is not dict:
            return None
        if set(value) - {"stage", "reason", "recorded_at", "simulation_run_id"}:
            return None
        if value.get("stage") != "api":
            return None
        reason = value.get("reason")
        if type(reason) is not str or reason not in REASONS:
            return None
        normalized = {
            "stage": "api", "reason": reason,
            "recorded_at": utc_text(parse_utc(value.get("recorded_at"), "received_at")),
        }
        if "simulation_run_id" in value:
            if not is_run_id(value["simulation_run_id"]):
                return None
            normalized["simulation_run_id"] = value["simulation_run_id"]
        return {**message_position(message), "quarantine": normalized}
    except ContractError:
        return None


class Session:
    def __init__(self, bootstrap, group):
        self.consumer = Consumer({
            "bootstrap.servers": bootstrap,
            "group.id": group,
            "enable.auto.commit": False,
            "enable.auto.offset.store": False,
            "allow.auto.create.topics": False,
            "auto.offset.reset": "error",
            "max.poll.interval.ms": 300_000,
            "session.timeout.ms": 10_000,
        })
        self.producer = Producer(kafka_producer_config(bootstrap))
        self.positions = {}
        self.last_heartbeat = 0.0
        self.consumer.subscribe(
            [EVENT_TOPIC, QUARANTINE_TOPIC],
            on_assign=self._assign, on_revoke=self._retire, on_lost=self._retire,
        )

    def _assign(self, consumer, partitions):
        committed = consumer.committed(partitions, timeout=4)
        for item in committed:
            if item.error:
                raise StreamError("committed_offsets_unavailable")
            low, high = consumer.get_watermark_offsets(item, timeout=2)
            if item.offset >= 0 and not low <= item.offset <= high:
                raise RetentionGap("retention_gap")
            if item.offset < 0:
                item.offset = low
        consumer.assign(committed)
        self.positions = {(item.topic, item.partition): item.offset for item in committed}

    def _retire(self, consumer, partitions):
        for item in partitions:
            self.positions.pop((item.topic, item.partition), None)

    def publish_quarantine(self, pending):
        if not pending:
            return []
        outcomes = {}
        for item in pending:
            delivery_id = item["delivery_id"]
            self.producer.produce(
                QUARANTINE_TOPIC,
                key=delivery_id.encode("ascii"), value=json_bytes(item["record"]),
                on_delivery=lambda error, _message, delivery_id=delivery_id: outcomes.update({delivery_id: error}),
            )
        not_delivered = self.producer.flush(timeout=11)
        if not_delivered or len(outcomes) != len(pending) or any(error is not None for error in outcomes.values()):
            raise StreamError("quarantine_broker_unavailable")
        return list(outcomes)

    def commit(self, next_offsets):
        offsets = [TopicPartition(topic, partition, offset) for (topic, partition), offset in next_offsets.items()]
        acknowledged = self.consumer.commit(offsets=offsets, asynchronous=False)
        if len(acknowledged) != len(offsets) or any(item.error for item in acknowledged):
            raise StreamError("commit_failed")
        self.positions.update({(item.topic, item.partition): item.offset for item in acknowledged})

    def publish_progress(self, store, tolerance, force=False):
        now = time.monotonic()
        if not force and now - self.last_heartbeat < 2:
            return
        committed, high = {}, {}
        for (topic, partition), next_offset in self.positions.items():
            if topic == EVENT_TOPIC:
                committed[partition] = next_offset
                _, high[partition] = self.consumer.get_watermark_offsets(TopicPartition(topic, partition), timeout=1)
        status = "running" if self.positions else "starting"
        store.heartbeat(status, committed_positions=committed, log_end_offsets=high, late_tolerance_ms=tolerance)
        self.last_heartbeat = now

    def close(self):
        self.consumer.close()


def process_batch(session, store, messages, validator, tolerance, crash_marker):
    started = time.monotonic()
    rows, api_rejections, next_offsets = [], [], {}
    for message in messages:
        error = message.error()
        if error:
            if error.code() == KafkaError._PARTITION_EOF:
                continue
            if error.code() in (KafkaError.OFFSET_OUT_OF_RANGE, KafkaError._AUTO_OFFSET_RESET):
                raise RetentionGap("retention_gap")
            raise StreamError("broker_consume_failed")
        topic, partition, offset = message.topic(), message.partition(), message.offset()
        next_offsets[(topic, partition)] = offset + 1
        if topic == EVENT_TOPIC:
            rows.append(validate_broker_message(message, validator))
        elif topic == QUARANTINE_TOPIC:
            record = api_quarantine_message(message)
            if record is not None:
                api_rejections.append(record)
        else:
            raise StreamError("unexpected_topic")
    if not next_offsets:
        return
    validation_ms = milliseconds(started)
    persisted = store.persist_batch(rows, api_rejections, tolerance)
    acknowledgment = session.publish_quarantine(persisted["pending_quarantine"])
    telemetry = {
        "active_ms": milliseconds(started), "validation_ms": validation_ms,
        "persistence_ms": persisted["persistence_ms"], "input_attempts": len(rows), "replays": persisted["replays"],
    } if rows else None
    quarantine_positions = {partition: offset for (topic, partition), offset in next_offsets.items() if topic == QUARANTINE_TOPIC}
    store.complete_batch(persisted["positions"], quarantine_positions, acknowledgment, telemetry)
    if rows and crash_marker and store.trigger_once(crash_marker):
        print("consumer_fault_before_commit", flush=True)
        os._exit(86)
    session.commit(next_offsets)


def consume_forever(bootstrap, group, batch_size, tolerance, validator, crash_marker, stop):
    with Store() as store:
        delay = 0.25
        while not stop.is_set():
            session = None
            try:
                store.initialize()
                session = Session(bootstrap, group)
                while not stop.is_set():
                    messages = session.consumer.consume(num_messages=batch_size, timeout=0.35)
                    process_batch(session, store, messages, validator, tolerance, crash_marker)
                    session.publish_progress(store, tolerance)
                    delay = 0.25
            except RetentionGap:
                try:
                    store.heartbeat("retention_gap")
                except StoreError:
                    pass
                print("consumer_retention_gap", flush=True)
                return 2
            except (StoreError, KafkaException, StreamError, BufferError) as exc:
                reason = str(exc) if isinstance(exc, (StoreError, StreamError)) else "broker_unavailable"
                print(f"consumer_degraded {reason}", flush=True)
                try:
                    store.heartbeat("degraded")
                except StoreError:
                    pass
            finally:
                if session is not None:
                    session.close()
            if not stop.is_set():
                stop.wait(delay)
                delay = min(3, delay * 2)
        try:
            store.heartbeat("stopped")
        except StoreError:
            pass
    return 0


def main():
    stop = threading.Event()
    for signum in (signal.SIGINT, signal.SIGTERM):
        signal.signal(signum, lambda *_: stop.set())
    validator = Validator(load_catalog(os.getenv("CRM_CATALOG")))
    tolerance = int(os.getenv("LATE_TOLERANCE_MS", "5000"))
    batch_size = int(os.getenv("KAFKA_BATCH_SIZE", "500"))
    if not 0 <= tolerance <= 86_400_000 or not 1 <= batch_size <= 1000:
        raise ValueError("invalid_consumer_configuration")
    return consume_forever(
        os.getenv("KAFKA_BOOTSTRAP", "broker:9092"),
        os.getenv("KAFKA_GROUP_ID", os.getenv("KAFKA_GROUP", "crm-v1")),
        batch_size, tolerance, validator, os.getenv("CRASH_BEFORE_COMMIT_ONCE"), stop,
    )


if __name__ == "__main__":
    raise SystemExit(main())
