"""Strict wire contract and privacy-preserving metadata for the CRM laboratory."""

import hashlib
import json
import math
import re
from datetime import datetime, timezone
from pathlib import Path
from uuid import UUID


EVENT_TOPIC = "crm.events.v1"
QUARANTINE_TOPIC = "crm.quarantine.v1"
MAX_BATCH = 1000
MAX_BODY_BYTES = 2 * 1024 * 1024
MAX_EVENT_BYTES = 8 * 1024
MAX_SEQUENCE = 2**53 - 1
SURFACES = frozenset({"discover", "route", "mi-ruta"})
REGIONS = frozenset({"altiplano", "centro", "huasteca", "zona-media"})

RUN = re.compile(r"run-[a-z0-9]+(?:-[a-z0-9]+)*", re.ASCII)
ACTOR = re.compile(r"actor-(0|[1-9][0-9]{0,11})", re.ASCII)
SCOPED_ID = {
    field: re.compile(rf"{prefix}-(0|[1-9][0-9]{{0,11}})-(0|[1-9][0-9]{{0,11}})", re.ASCII)
    for field, prefix in (("session_id", "session"), ("route_id", "route"), ("impression_id", "imp"))
}
UTC_DATE = re.compile(
    r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}"
    r"(?:\.[0-9]{1,6})?(?:Z|\+00:00)",
    re.ASCII,
)
BASE_FIELDS = frozenset({
    "schema_version", "source", "synthetic", "event_id", "event_type", "event_time",
    "simulation_run_id", "demo_actor_id", "session_id", "profile_id", "event_sequence",
})
EVENT_FIELDS = {
    "destination_view": ({"destination_id"}, set()),
    "category_selected": ({"interest", "selected"}, set()),
    "recommendation_seen": ({"place_ids", "surface"}, set()),
    "recommendation_added": ({"destination_id", "route_id"}, set()),
    "destination_added": ({"destination_id", "route_id"}, set()),
    "destination_removed": ({"destination_id", "route_id"}, set()),
    "route_generated": ({"route_id"}, {"stops"}),
    "favorite_added": ({"destination_id"}, set()),
    "favorite_removed": ({"destination_id"}, set()),
    "destination_impression": ({"destination_id", "impression_id", "visible_fraction", "visible_ms"}, {"surface"}),
    "destination_click": ({"destination_id", "impression_id"}, {"surface"}),
    "campaign_impression": ({"campaign_id", "impression_id", "visible_fraction", "visible_ms"}, {"destination_id", "surface"}),
    "campaign_click": ({"campaign_id", "impression_id"}, {"destination_id", "surface"}),
}
CONTROL_FIELDS = frozenset({
    "simulation_run_id", "destination_id", "revision", "recorded_at", "valid_from", "valid_to",
    "capacity", "reservations", "available", "access", "environmental_status", "source",
    "verified", "case",
})
REASONS = frozenset({
    "invalid_json", "body_size", "batch_size", "content_type", "not_an_object",
    "event_size", "unknown_fields", "missing_fields", "schema_version", "source",
    "synthetic", "event_type", "event_id", "run_id", "actor_id", "scoped_id",
    "event_sequence", "event_time", "received_at", "profile_id", "destination_id",
    "campaign_id", "interest", "selected", "surface", "place_ids", "stops",
    "visible_fraction", "visible_ms", "invalid_key", "identity_conflict",
})


class ContractError(ValueError):
    def __init__(self, reason):
        super().__init__(reason)
        self.reason = reason


def _unique_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ContractError("invalid_json")
        result[key] = value
    return result


def _reject_constant(_value):
    raise ContractError("invalid_json")


def decode_json(data):
    try:
        return json.loads(data.decode("utf-8"), object_pairs_hook=_unique_keys, parse_constant=_reject_constant)
    except (UnicodeError, ValueError, RecursionError):
        raise ContractError("invalid_json") from None


def json_bytes(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False).encode("ascii")


def utc_text(value=None):
    if value is None:
        value = datetime.now(timezone.utc)
    return value.astimezone(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def parse_utc(value, reason):
    if type(value) is not str or not UTC_DATE.fullmatch(value):
        raise ContractError(reason)
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        raise ContractError(reason) from None


def is_run_id(value):
    return type(value) is str and len(value) <= 64 and RUN.fullmatch(value) is not None


def _listed(value, entries):
    return type(value) is str and value in entries


def _integer(value, low, high):
    return type(value) is int and low <= value <= high


def _uuid(value):
    if type(value) is not str or len(value) != 36:
        return False
    try:
        parsed = UUID(value)
    except ValueError:
        return False
    return str(parsed) == value and parsed.int != 0


def load_catalog(path=None):
    location = Path(path) if path else Path(__file__).with_name("catalog.json")
    catalog = decode_json(location.read_bytes())
    if type(catalog) is not dict or not {"destinations", "profiles", "interests", "campaigns"} <= catalog.keys():
        raise ValueError("invalid_catalog")
    for key in ("profiles", "interests", "campaigns"):
        entries = catalog[key]
        if type(entries) is not list or not entries or any(type(value) is not str or not value for value in entries):
            raise ValueError("invalid_catalog")
        if len(set(entries)) != len(entries):
            raise ValueError("invalid_catalog")
    destinations = catalog["destinations"]
    if type(destinations) is not list or not destinations:
        raise ValueError("invalid_catalog")
    identifiers = set()
    for destination in destinations:
        if type(destination) is not dict or not {"id", "name", "region", "interests"} <= destination.keys():
            raise ValueError("invalid_catalog")
        identifier = destination["id"]
        if type(identifier) is not str or not identifier or identifier in identifiers:
            raise ValueError("invalid_catalog")
        if type(destination["name"]) is not str or not _listed(destination["region"], REGIONS):
            raise ValueError("invalid_catalog")
        interests = destination["interests"]
        if type(interests) is not list or any(not _listed(value, catalog["interests"]) for value in interests):
            raise ValueError("invalid_catalog")
        identifiers.add(identifier)
    return catalog


class Validator:
    def __init__(self, catalog):
        self.destinations = frozenset(value["id"] for value in catalog["destinations"])
        self.profiles = frozenset(catalog["profiles"])
        self.interests = frozenset(catalog["interests"])
        self.campaigns = frozenset(catalog["campaigns"])

    def event(self, value, broker=False):
        if type(value) is not dict:
            raise ContractError("not_an_object")
        event_type = value.get("event_type")
        if not _listed(event_type, EVENT_FIELDS):
            raise ContractError("event_type")
        required_fields, optional = EVENT_FIELDS[event_type]
        required = BASE_FIELDS | required_fields
        if broker:
            required |= {"received_at"}
        allowed = required | optional | {"campaign_id"}
        if value.keys() - allowed:
            raise ContractError("unknown_fields")
        if required - value.keys():
            raise ContractError("missing_fields")

        if type(value["schema_version"]) is not int or value["schema_version"] != 1:
            raise ContractError("schema_version")
        if value["source"] != "simulator":
            raise ContractError("source")
        if value["synthetic"] is not True:
            raise ContractError("synthetic")
        if not _uuid(value["event_id"]):
            raise ContractError("event_id")
        if not is_run_id(value["simulation_run_id"]):
            raise ContractError("run_id")
        actor = value["demo_actor_id"]
        actor_match = ACTOR.fullmatch(actor) if type(actor) is str else None
        if actor_match is None:
            raise ContractError("actor_id")
        for field, pattern in SCOPED_ID.items():
            if field in value:
                candidate = value[field]
                match = pattern.fullmatch(candidate) if type(candidate) is str else None
                if match is None or (field != "impression_id" and match[1] != actor_match[1]):
                    raise ContractError("scoped_id")
        if not _integer(value["event_sequence"], 1, MAX_SEQUENCE):
            raise ContractError("event_sequence")
        for field, universe in (
            ("profile_id", self.profiles), ("destination_id", self.destinations),
            ("campaign_id", self.campaigns), ("interest", self.interests), ("surface", SURFACES),
        ):
            if field in value and not _listed(value[field], universe):
                raise ContractError(field)
        self._context(value)
        normalized = dict(value)
        normalized["event_time"] = utc_text(parse_utc(value["event_time"], "event_time"))
        if broker:
            normalized["received_at"] = utc_text(parse_utc(value["received_at"], "received_at"))
        if "visible_fraction" in normalized:
            normalized["visible_fraction"] = float(normalized["visible_fraction"]) + 0.0
        if len(json_bytes(normalized)) > MAX_EVENT_BYTES:
            raise ContractError("event_size")
        return normalized

    def _context(self, value):
        if "selected" in value and type(value["selected"]) is not bool:
            raise ContractError("selected")
        if "place_ids" in value:
            places = value["place_ids"]
            if (type(places) is not list or not 1 <= len(places) <= 20
                    or any(not _listed(place, self.destinations) for place in places)
                    or len(set(places)) != len(places)):
                raise ContractError("place_ids")
        for field, maximum in (("stops", 100), ("visible_ms", 86_400_000)):
            if field in value and not _integer(value[field], 0, maximum):
                raise ContractError(field)
        if "visible_fraction" in value:
            fraction = value["visible_fraction"]
            if type(fraction) not in (int, float) or not 0 <= fraction <= 1 or not math.isfinite(fraction):
                raise ContractError("visible_fraction")

    def control(self, value):
        if type(value) is not dict or value.keys() != CONTROL_FIELDS:
            raise ContractError("control_fields")
        if not is_run_id(value["simulation_run_id"]):
            raise ContractError("run_id")
        if not _listed(value["destination_id"], self.destinations):
            raise ContractError("destination_id")
        if value["source"] != "synthetic-operations-v1":
            raise ContractError("source")
        for field in ("available", "verified"):
            if type(value[field]) is not bool:
                raise ContractError(field)
        for field, minimum in (("revision", 1), ("capacity", 0), ("reservations", 0)):
            if not _integer(value[field], minimum, MAX_SEQUENCE):
                raise ContractError(field)
        for field, options in (
            ("access", {"open", "restricted", "closed"}),
            ("environmental_status", {"clear", "alert"}),
            ("case", {"A", "B", "D"}),
        ):
            if not _listed(value[field], options):
                raise ContractError(field)
        normalized = dict(value)
        for field in ("recorded_at", "valid_from", "valid_to"):
            normalized[field] = utc_text(parse_utc(value[field], field))
        if normalized["valid_from"] >= normalized["valid_to"]:
            raise ContractError("validity")
        return normalized


def partition_key(event):
    return f'{event["simulation_run_id"]}|{event["demo_actor_id"]}'.encode("ascii")


def fingerprint(event):
    fields = BASE_FIELDS | set().union(*EVENT_FIELDS[event["event_type"]]) | {"campaign_id"}
    business = {field: event[field] for field in fields if field in event}
    business["event_time"] = utc_text(parse_utc(business["event_time"], "event_time"))
    if "visible_fraction" in business:
        business["visible_fraction"] = float(business["visible_fraction"]) + 0.0
    return hashlib.sha256(json_bytes(business)).hexdigest()


def rejection(reason, stage, body=None, position=None):
    if reason not in REASONS or stage not in {"api", "consumer"}:
        raise ValueError("invalid_quarantine_metadata")
    record = {"reason": reason, "stage": stage, "recorded_at": utc_text()}
    if type(body) is dict and body.get("source") == "simulator" and body.get("synthetic") is True:
        run_id = body.get("simulation_run_id")
        if is_run_id(run_id):
            record["simulation_run_id"] = run_id
    if position is not None:
        record.update({field: position[field] for field in ("topic", "partition", "offset")})
    return record
