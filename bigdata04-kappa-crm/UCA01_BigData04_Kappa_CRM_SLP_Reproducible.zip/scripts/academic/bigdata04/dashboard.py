"""Loopback dashboard that serves complete, cached CRM cuts."""

import argparse
import asyncio
import json
import logging
import os
import secrets
import time
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

from tornado.httpclient import AsyncHTTPClient, HTTPClientError, HTTPRequest
from tornado.web import Application, RequestHandler

from contracts import is_run_id, load_catalog
from policy import stamp, utc
from reducer import LABEL, logical_hash, reduce_events
from store import Store


DIRECTORY = Path(__file__).resolve().parent
LOGGER = logging.getLogger(__name__)


def monitor(snapshot):
    audit = dict(snapshot["audit"])
    audit["positions"] = snapshot["positions"]
    counts = audit.get("counts", {})
    audit["canonical_events"] = len(snapshot["events"])
    audit["broker_deliveries"] = sum(counts.get(key, 0) for key in ("new", "duplicate", "conflict", "rejected"))
    audit["integrity"] = "conflictive" if counts.get("conflict") else "reconciled"
    return audit


def change_key(progress):
    return {name: progress[name] for name in ("positions", "control_count", "quarantine_count")}


def add_progress(audit, progress):
    live = {key: value for key, value in progress.items() if key not in change_key(progress)}
    return {**audit, **live}


def dashboard_metrics(metrics):
    daily = metrics["ctr_daily"]
    recent = set(sorted({row["day_utc"] for row in daily if row["family"] == "campaign"})[-14:])
    return {**metrics, "ctr_daily": [row for row in daily if row["family"] == "campaign" and row["day_utc"] in recent]}


class Cuts:
    def __init__(self, refresh, api_health, historical_db):
        self.refresh = refresh
        self.api_health = api_health
        self.historical_db = historical_db
        self.history = {"available": False, "label": "[SIN_DATOS] Histórico oficial fuera de este corte"}
        self.catalog = load_catalog()
        self.worker = ThreadPoolExecutor(max_workers=1, thread_name_prefix="proyeccion")
        self.store = None
        self.runs = []
        self.cuts = OrderedDict()
        self.wanted = OrderedDict()
        self.services = {"dashboard": True, "mongodb": None, "api": None, "broker": None}
        self.error = None

    def request_run(self, run_id):
        self.wanted.setdefault(run_id, None)
        while len(self.wanted) > 4:
            self.wanted.popitem(last=False)

    def read(self, requested):
        started = time.perf_counter()
        if self.store is None:
            self.store = Store()
        try:
            runs = self.store.list_runs()
            run_id = requested or next(iter(runs), None)
            if run_id is None:
                return runs, None, None
            previous = self.cuts.get(run_id)
            if previous is None:
                stored = self.store.read_cut(run_id)
                if stored:
                    previous = {"key": change_key(stored["monitor"]), "recheck_at": utc(stored["recheck_at"]), "payload": stored}
            progress = self.store.read_progress(run_id)
            now = datetime.now(timezone.utc)
            key = change_key(progress)
            if previous and previous["key"] == key and now < previous["recheck_at"]:
                payload = previous["payload"]
                payload = {**payload, "monitor": add_progress(payload["monitor"], progress)}
                return runs, run_id, {**previous, "payload": payload}
            snapshot = self.store.read_snapshot(run_id, include_deliveries=False)
        except Exception:
            self.store.close()
            self.store = None
            raise
        projection = reduce_events(snapshot["events"], self.catalog, snapshot["controls"], now, run_id)
        tables = projection["tables"]
        control_times = [utc(control[field]) for control in snapshot["controls"]
                         for field in ("recorded_at", "valid_from", "valid_to")]
        recheck_at = min((value for value in control_times if value > now), default=datetime.max.replace(tzinfo=timezone.utc))
        audit = add_progress(monitor(snapshot), progress)
        payload = {
            "simulation_run_id": run_id, "cut_id": logical_hash({"hashes": projection["hashes"],
                                                                  "positions": snapshot["positions"]})[:24],
            "label": LABEL, "as_of": projection["as_of"], "published_at": stamp(datetime.now(timezone.utc)),
            "refresh_ms": (time.perf_counter() - started) * 1_000, "positions": snapshot["positions"],
            "hashes": projection["hashes"], "monitor": audit, "metrics": dashboard_metrics(projection["metrics"]),
            "recheck_at": stamp(recheck_at), "policies": tables["decisions"], "policy_history": tables["decision_history"][-100:],
            "history": [
                {key: event[key] for key in ("event_time", "event_type", "destination_id", "event_sequence")}
                for event in tables["state_actions"][-40:][::-1]
            ],
        }
        self.store.publish_cut(run_id, payload)
        payload["refresh_total_ms"] = (time.perf_counter() - started) * 1_000
        return runs, run_id, {"key": change_key(audit), "recheck_at": recheck_at, "payload": payload}

    async def service_status(self):
        try:
            response = await AsyncHTTPClient().fetch(HTTPRequest(self.api_health, request_timeout=2), raise_error=False)
            data = json.loads(response.body)
            return response.code in (200, 503), data.get("broker_available", False)
        except (HTTPClientError, OSError, ValueError):
            return False, None

    async def start(self):
        if self.historical_db is not None:
            from export import historical_context

            try:
                self.history = await asyncio.get_running_loop().run_in_executor(self.worker, historical_context, self.historical_db)
            except Exception as error:
                LOGGER.warning("No se pudo leer el contexto histórico (%s)", type(error).__name__)
        while True:
            service = asyncio.create_task(self.service_status())
            requested = self.wanted.popitem(last=False)[0] if self.wanted else None
            try:
                self.runs, run_id, snapshot = await asyncio.get_running_loop().run_in_executor(self.worker, self.read, requested)
                if snapshot is not None:
                    self.cuts[run_id] = snapshot
                    self.cuts.move_to_end(run_id)
                    while len(self.cuts) > 4:
                        self.cuts.popitem(last=False)
                self.services["mongodb"], self.error = True, None
            except Exception as error:
                LOGGER.warning("No se pudo actualizar el corte (%s)", type(error).__name__)
                self.services["mongodb"], self.error = False, "proyeccion_no_disponible"
            self.services["api"], self.services["broker"] = await service
            await asyncio.sleep(self.refresh)

    def response(self, run_id):
        if run_id:
            self.request_run(run_id)
        default_run = next(iter(self.runs), None)
        record = self.cuts.get(run_id or default_run)
        shared = {"label": LABEL, "runs": self.runs, "services": self.services, "historical_context": self.history,
                  "refresh_error": self.error, "refresh_seconds": self.refresh}
        if record is None:
            return {**shared, "simulation_run_id": run_id or default_run, "status": "pending", "cut_id": None}
        return {**shared, **record["payload"], "status": "stale" if self.error else "ready"}


class Handler(RequestHandler):
    def initialize(self, cuts):
        self.cuts = cuts

    def set_default_headers(self):
        self.set_header("Cache-Control", "no-store")
        self.set_header("X-Content-Type-Options", "nosniff")
        self.set_header("Referrer-Policy", "no-referrer")
        self.set_header("X-Frame-Options", "DENY")

    def write_error(self, status_code, **kwargs):
        self.finish({"status": "error", "code": status_code})


class Page(Handler):
    template = (DIRECTORY / "dashboard.html").read_text(encoding="utf-8")

    def get(self):
        nonce = secrets.token_urlsafe(18)
        self.set_header("Content-Type", "text/html; charset=UTF-8")
        self.set_header("Content-Security-Policy", "default-src 'none'; connect-src 'self'; frame-ancestors 'none'; "
                        f"base-uri 'none'; script-src 'nonce-{nonce}'; style-src 'nonce-{nonce}'")
        self.finish(self.template.replace("{{nonce}}", nonce))


class Snapshot(Handler):
    def get(self):
        run_id = self.get_query_argument("run_id", default=None)
        if run_id is not None and not is_run_id(run_id):
            self.send_error(400)
            return
        self.set_header("Cache-Control", "private, no-cache")
        self.finish(self.cuts.response(run_id))


class Runs(Handler):
    def get(self):
        self.finish({"runs": self.cuts.runs})


class Health(Handler):
    def get(self):
        self.finish({"status": "degraded" if self.cuts.error else "ok", "services": self.cuts.services})


def make_app(cuts):
    routes = ((r"/", Page), (r"/api/snapshot", Snapshot), (r"/api/runs", Runs), (r"/health", Health))
    return Application([(path, handler, {"cuts": cuts}) for path, handler in routes],
                       compress_response=True, default_handler_class=Handler, default_handler_args={"cuts": cuts})


def main():
    parser = argparse.ArgumentParser(description="Tablero local de inteligencia turística")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8501)
    parser.add_argument("--refresh-seconds", type=float, default=2.5)
    parser.add_argument("--historical-db", type=Path,
                        default=Path(os.environ["CRM_HISTORICAL_DB"]) if "CRM_HISTORICAL_DB" in os.environ else None)
    parser.add_argument("--api-health", default=os.environ.get("INGEST_HEALTH_URL", "http://127.0.0.1:18404/health"))
    args = parser.parse_args()
    if not 1 <= args.refresh_seconds <= 60:
        parser.error("el intervalo de corte debe estar entre 1 y 60 segundos")

    async def serve():
        cuts = Cuts(args.refresh_seconds, args.api_health, args.historical_db)
        make_app(cuts).listen(args.port, address=args.host)
        await cuts.start()

    asyncio.run(serve())


if __name__ == "__main__":
    main()
