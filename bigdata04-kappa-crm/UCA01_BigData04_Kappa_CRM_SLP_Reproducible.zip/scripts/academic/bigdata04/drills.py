"""Pruebas de fronteras, caída entre escritura y commit, y replay en una base vacía."""
import argparse
import json
import time
from pathlib import Path
from urllib import request, error
from benchmark import RESULTS, Stack, command, write, utc
from contracts import is_run_id
import simulator
from collections import Counter


def replay(stack, run, result):
    manifest_path=RESULTS/result["manifest"]
    canon=json.loads(manifest_path.read_text(encoding="utf-8"))
    suffix=str(time.time_ns())
    database="slp_bigdata04_replay_"+suffix
    group="crm-replay-"+suffix
    name="slp-bigdata04-replay-"+suffix
    flags=["-e","MONGO_DATABASE="+database,"-e","KAFKA_GROUP_ID="+group]
    prefix=stack.cli+["exec","-T",*flags,"api","python"]
    # Copy original, immutable revisions with exact timestamps. Never rewrite the source run.
    code=("import sys; from store import Store; source=Store(database='slp_bigdata04_demo'); target=Store(); "
          "controls=source.read_controls(sys.argv[1]); "
          "[target.put_control({k:v for k,v in r.items() if k not in ('_id','fingerprint')}) for r in controls]; "
          "source.close(); target.close()")
    command(prefix+["-c",code,run])
    stack.compose("run","-d","--no-deps","--name",name,*flags,"-e","CRASH_BEFORE_COMMIT_ONCE="+suffix,
                  "consumer","consumer.py")
    try:
        consumed = command(["docker","wait",name],90)
        if consumed.strip() != "86":
            raise RuntimeError("No se observó la caída controlada antes del commit: "+consumed)
        during=json.loads(command(prefix+["lag.py"]))
        restart=time.perf_counter()
        command(["docker","start",name])
        while time.perf_counter()-restart<300:
            final=json.loads(command(prefix+["lag.py"]))
            if not sum(row["lag"] for row in final.values()):
                break
            time.sleep(.7)
        else:
            raise TimeoutError("Replay pendiente")
        elapsed=time.perf_counter()-restart
        command(prefix+["export.py","--run-id",run,"--output","/results/replay/"+suffix,
                        "--as-of",canon["as_of"],"--seed",str(result["publication"]["seed"])],timeout=500)
        copy_path=next((RESULTS/"replay"/suffix/run).glob("*/manifest.json"))
        copy=json.loads(copy_path.read_text(encoding="utf-8"))
        assert copy["hashes"]==canon["hashes"]
        assert all(info["rows"]==copy["tables"][key]["rows"] for key,info in canon["tables"].items())
        audit=json.loads((copy_path.parent/"indicators.json").read_text(encoding="utf-8"))["monitor"]
        assert audit["replay_attempts"]>0
        return {"source_manifest":result["manifest"],"replay_manifest":str(copy_path.relative_to(RESULTS)),
                "group":group,"database":database,"fault_exit":86,"after_crash":during,"end":final,"drain_s":elapsed,
                "reread_offsets":audit["replay_attempts"],"hashes":copy["hashes"],"tables":len(copy["tables"])}
    finally:
        command(["docker","stop","-t","8",name])


def failures(stack, run):
    cli=argparse.ArgumentParser()
    simulator.arguments(cli)
    args=cli.parse_args(["--run",run,"--count","30","--duplicates","0","--invalid","0"])
    body=next(simulator.attempts(args,Counter()))
    stack.drain()
    stack.compose("stop","-t","10","broker")
    try:
        req=request.Request("http://127.0.0.1:18404/events",data=json.dumps(body).encode(),
                            headers={"Content-Type":"application/json"})
        try:
            request.urlopen(req,timeout=30)
            raise AssertionError("La API aceptó un evento sin broker.")
        except error.HTTPError as exc:
            broker_status=exc.code
            assert broker_status==503
    finally:
        stack.compose("start","broker")
    until=time.monotonic()+90
    while time.monotonic()<until:
        try:
            if json.load(request.urlopen("http://127.0.0.1:18404/health",timeout=5)).get("broker_available"):
                break
        except (OSError,ValueError):
            pass
        time.sleep(1)
    before=stack.drain()
    stack.compose("stop","-t","10","mongo")
    try:
        published=simulator.publish(args)
        time.sleep(2)
        during=json.loads(stack.python("lag.py"))
        assert all(during[k]["committed"]==v["committed"] for k,v in before.items())
        assert sum(v["lag"] for v in during.values())==published["attempts"]
    finally:
        stack.compose("start","mongo")
    end=stack.drain()
    return {"broker_off_http":broker_status,"mongodb_off":during,"before":before,"after":end,
            "pending_events_while_mongo_off":published["attempts"]}


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--run",required=True)
    p.add_argument("--offline",action="store_true")
    args=p.parse_args()
    assert is_run_id(args.run)
    root=RESULTS/"benchmarks"/args.run
    stack=Stack(args.offline)
    result=json.loads((root/"result.json").read_text(encoding="utf-8"))
    report={"at":utc(),"replay":replay(stack,args.run,result)}
    write(root/"replay.json",report)
    report["faults"]=failures(stack,"run-fault-"+str(time.time_ns()))
    # Reopen the original database after the Mongo/Kafka restart and verify its corpus.
    count = stack.compose("exec","-T","-e","AUDIT_RUN="+args.run,"mongo","mongosh","--quiet","--eval",
             "print(db.getSiblingDB('slp_bigdata04_demo').events.countDocuments({simulation_run_id:process.env.AUDIT_RUN}))")
    assert int(count)==result["publication"]["accepted"]-result["publication"].get("duplicates_generated",0)
    report["original_unique_after_restart"]=int(count)
    write(root/"drills.json",report)
    print(json.dumps(report))
