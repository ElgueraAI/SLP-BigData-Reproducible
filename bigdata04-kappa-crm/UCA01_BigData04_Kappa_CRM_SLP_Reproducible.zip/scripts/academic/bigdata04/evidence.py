"""Reconciliar corridas seleccionadas y preparar únicamente agregados para el cuaderno."""
import argparse
import json
from pathlib import Path


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def render_report(runs, root):
    small, _, large = sorted(runs,key=lambda row:row["count"])
    drills = read(root/"benchmarks"/small["run"]/"drills.json")
    env = read(root/"benchmarks"/large["run"]/"environment.json")
    replay = drills["replay"]
    lines = ["# Resultados verificados de Big Data 04","",
             "[OBSERVADO] Mediciones del 25 de noviembre de 2026, rama `feature/academic-multiagents`, base `3fe53fc`. "
             "Cada fila corresponde a una ejecución completa con semilla 42. El corpus es [SIMULADO]. "
             "La publicación se hizo por HTTP en lotes de hasta 250 intentos con confirmación de Kafka. "
             "El contador de eventos únicos se cotejó con MongoDB, Parquet, DuckDB y el tablero.",
             "", "## Conservación y rendimiento", "",
             "| Intentos | Kafka aceptó | Cuarentena API | Únicos | Duplicados | Únicos tardíos | E2E únicos/s | Consumo activo únicos/s |",
             "|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for r in runs:
        lines.append(f"| {r['count']:,} | {r['accepted']:,} | {r['rejected']:,} | {r['unique']:,} | {r['duplicates']:,} | "
                     f"{r['late_new']:,} | {r['throughput_e2e']:.2f} | {r['throughput_active']:.2f} |")
    lines += ["", "Cada intento terminó aceptado o rechazado. Los aceptados se reconciliaron con únicos y duplicados; el rezago final fue cero en las tres corridas. "
              "El rendimiento extremo a extremo divide únicos por el intervalo entre inicio de publicación y drenaje confirmado. "
              "El activo divide únicos por la suma de milisegundos activos de los lotes de entrada. "
              "El caso de 1.000 incluye una pausa controlada. La marca temporal máxima de cada partición es compartida entre corridas y el generador reinicia su reloj. "
              "El conteo de tardíos observados (umbral 5 s) puede incluir eventos adicionales a los retenidos deliberadamente por el simulador.",
              "", "| Intentos | Media ms | p50 ms | p95 ms | p99 ms | Generación s | Publicación s | Validación s | Persistencia s | Consulta DuckDB s | Refresco servidor s |",
              "|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for r in runs:
        lat,p=r["latency_ms"],r["phases_s"]
        lines.append("| "+" | ".join([f"{r['count']:,}"]+[f"{lat[k]:.2f}" for k in ("mean","p50","p95","p99")]+
                                  [f"{p[k]:.3f}" for k in ("generation","publication","validation","persistence","query","dashboard")])+" |")
    lines += ["", "Las latencias miden desde la aceptación para publicación hasta el acuse durable del primer registro en MongoDB. "
              "Se empleó interpolación lineal sobre nuevos únicos. Las fases se superponen y el refresco corresponde al servidor. "
              "El sondeo del navegador y el tiempo de dibujo de la pantalla se evalúan aparte.", "", "## Recursos y almacenamiento","",
              f"Host de medición: {env['platform']}. CPU {env['cpu_model']}, {env['cpu_logical']} procesadores lógicos, "
              f"{env['memory'].strip()}. Docker Engine {env['docker']}; {env['compose']}.",
              "", "| Intentos | RSS/cgroup máximo muestreado por servicio (MiB)¹ | CPU acumulada observada por servicio (s) | Archivos exportados (bytes) | Mongo al cierre con índices (bytes) |",
              "|---:|---|---|---:|---:|"]
    for r in runs:
        resources=r["resources"]
        mem=", ".join(f"{s} {v['peak_sampled_bytes']/2**20:.1f}" for s,v in resources.items())
        cpu=", ".join(f"{s} {v['cpu_observed_s']:.2f}" if v['cpu_observed_s'] is not None else f"{s} s/d" for s,v in resources.items())
        disk=r["database_after"]
        lines.append(f"| {r['count']:,} | {mem} | {cpu} | {r['export_bytes']:,} | {disk['storage_bytes']+disk['index_bytes']:,} |")
    lines += ["","¹ Memoria total cargada al cgroup desde `memory.current`, con caché incluida. El máximo es el mayor valor muestreado. "
              "La CPU se obtiene de diferencias positivas de `cpu.stat/usage_usec` entre muestras del mismo contenedor. "
              "Los intervalos de indisponibilidad constan en resources.json. Mongo mide el almacenamiento acumulado de la base de demostración. "
              "Se conserva una medición por escala y un único nodo con réplica uno. [SIN_DATOS] Escalabilidad entre nodos, alta disponibilidad y variación entre repeticiones.",
              "", "## Recuperación y replay","",
              f"En {small['run']}, el rezago pasó de {small['recovery_lag']['before']} a {small['recovery_lag']['during']} offsets durante la pausa, "
              f"y a {small['recovery_lag']['after']} tras {small['recovery_s']:.2f} s desde la orden de arranque. "
              f"El replay independiente salió con código {replay['fault_exit']} al inyectar una caída entre persistencia y commit. "
              f"Se releyeron {replay['reread_offsets']} posiciones. Coincidieron el corpus, las restricciones, los resultados y las cantidades por tabla en {replay['tables']} tablas. "
              f"Con Kafka detenido, HTTP respondió {drills['faults']['broker_off_http']}. Sin Mongo, {drills['faults']['pending_events_while_mongo_off']} eventos quedaron pendientes "
              f"sin adelantar el commit. Al reabrir los servicios persistieron {drills['original_unique_after_restart']} eventos canónicos en la primera corrida.",
              "", "## Trazabilidad","", "| Corrida | Corte exportado | SHA-256 lógico de los resultados |","|---|---|---|"]
    for r in runs:
        lines.append(f"| `{r['run']}` | `{r['cut']}` | `{r['hashes']['results']}` |")
    lines += ["","Los manifiestos completos están bajo `.bigdata-private/bigdata04/exports/<corrida>/<corte>/manifest.json`. "
              "Las fases y los recursos pueden cotejarse en `benchmarks/<corrida>/{result,environment,resources}.json`. "
              "El laboratorio ejecutó el perfil Docker offline. La construcción mediante descargas del Dockerfile portátil queda sin verificar. "
              "[Agregados usados por el cuaderno](../../../scripts/academic/bigdata04/evidence/measurements.json) · "
              "[Protocolo de reproducción](../../../scripts/academic/bigdata04/README.md).",""]
    return "\n".join(lines).replace("RSS/cgroup máximo","Cgroup máximo")

def summarize(root, run):
    bench = root/"benchmarks"/run
    result = read(bench/"result.json")
    manifest_path = root/result["manifest"]
    manifest = read(manifest_path)
    indicators = read(manifest_path.parent/"indicators.json")
    audit = indicators["monitor"]
    pub, counts, phase = result["publication"], audit["counts"], result["phase_delta"]
    assert manifest["simulation_run_id"] == indicators["simulation_run_id"] == run
    assert pub["attempts"] == pub["accepted"] + pub["rejected"]
    assert pub["rejected"] == audit["quarantine_count"]
    assert counts["deliveries"] == pub["accepted"]
    assert counts["new"] + counts["duplicate"] + counts["conflict"] + counts["rejected"] == counts["deliveries"]
    assert counts["new"] == manifest["tables"]["events"]["rows"] == audit["latency_ms"]["n"]
    assert counts["conflict"] == counts["rejected"] == result["final_lag"] == 0
    after = read(bench/"dashboard-after.json")
    assert after["body"]["monitor"]["counts"]["new"] == counts["new"]
    assert after["body"]["metrics"]["campaign_metrics"] == indicators["metrics"]["campaign_metrics"]
    recovery = result["recovery"]
    lag = {name:sum(r["lag"] for r in states.values()) for name,states in recovery.items()
           if name in ("before","during","after")}
    return {"run":run, "at":result["completed_at"], "count":pub["attempts"],"seed":pub["seed"],
            "accepted":pub["accepted"],"rejected":pub["rejected"],"unique":counts["new"],"duplicates":counts["duplicate"],
            "late_new":counts["late_new"],"errors":counts["conflict"]+counts["rejected"],
            "latency_ms":audit["latency_ms"], "elapsed_s":result["flow_s"],
            "throughput_e2e":counts["new"]/result["flow_s"],"throughput_active":counts["new"]/(phase["active_ms"]/1000),
            "phases_s":{"generation":pub["generation_s"],"publication":pub["publish_s"],
                        "validation":phase["validation_ms"]/1000,"persistence":phase["persistence_ms"]/1000,
                        "query":manifest["query_ms"]/1000,"dashboard":after["body"]["refresh_ms"]/1000},
            "recovery_s":recovery.get("seconds"),"recovery_lag":lag, "final_lag":result["final_lag"],
            "resources":result["resources"],"database_after":result["database_after"],
            "export_bytes":sum(item["bytes"] for item in manifest["files"].values()),
            "cut":manifest["cut_id"],"hashes":manifest["hashes"],"campaign_metrics":indicators["metrics"]["campaign_metrics"],
            "states":indicators["metrics"]["state_totals"],"recommendations":indicators["metrics"]["recommendations"],
            "policy_history":indicators["policy_history"],"policy_counts":{
                status:sum(row["status"]==status for row in indicators["policies"]) for status in ("candidato","pausa","sin_datos","bloqueado")},
            "history":manifest.get("historical_context"),"manifest":result["manifest"]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--report", type=Path)
    parser.add_argument("runs", nargs="+")
    args=parser.parse_args()
    runs=[summarize(args.root, run) for run in args.runs]
    assert sorted(r["count"] for r in runs)==[1000,10000,100000]
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps({"label":"ENTORNO ACADÉMICO — DATOS SINTÉTICOS","runs":runs},
                                   indent=2,ensure_ascii=False),encoding="utf-8")
    if args.report:
        args.report.write_text(render_report(runs,args.root),encoding="utf-8")
