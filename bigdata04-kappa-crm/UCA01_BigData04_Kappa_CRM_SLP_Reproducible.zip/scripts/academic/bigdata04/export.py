"""Publish independently verifiable Parquet and DuckDB versions of CRM cuts."""

import argparse
import errno
import hashlib
import json
import os
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

import duckdb
import pyarrow as pa
import pyarrow.parquet as pq

from contracts import is_run_id, load_catalog
from policy import stamp
from reducer import LABEL, canonical_json, logical_hash, reduce_events


FORMAT_VERSION = 1
DIRECTORY = Path(__file__).resolve().parent
DEFAULT_OUTPUT = (DIRECTORY.parents[2] / ".bigdata-private" / "bigdata04" / "exports"
                  if len(DIRECTORY.parents) >= 3 else Path("/results/exports"))
TEXT = pa.string()
INT = pa.int64()
BOOL = pa.bool_()
FLOAT = pa.float64()
LIST = pa.list_(TEXT)
COMMON = [("simulation_run_id", TEXT), ("cut_id", TEXT)]
ACTOR = [("demo_actor_id", TEXT), ("destination_id", TEXT), ("active", BOOL), ("event_sequence", INT),
         ("event_id", TEXT), ("event_time", TEXT)]
CTR = [("eligible_impressions", INT), ("clicked_impressions", INT), ("eligible_click_actions", INT),
       ("click_actions", INT), ("ctr_pct", FLOAT)]
GROUP = [("family", TEXT), ("campaign_id", TEXT)]
METRICS = [(key, INT) for key in ("events", "views", "route_saves", "favorite_saves", "routes_generated")]
OPERATING = [(key, TEXT) for key in ("case", "recorded_at", "valid_from", "valid_to", "source", "access", "environmental_status")]
OPERATING += [("revision", INT), ("capacity", INT), ("reservations", INT), ("available", BOOL), ("verified", BOOL)]
DECISION = [("destination_id", TEXT), ("evaluated_at", TEXT), ("rule_version", TEXT), ("status", TEXT), ("reason", TEXT),
            ("places_available", INT), ("minimum_places", INT), ("unit", TEXT), ("automatic_increase", BOOL)] + OPERATING
SCHEMAS = {
    "events": [(key, TEXT) for key in ("event_id", "event_type", "event_time", "source", "demo_actor_id", "session_id",
                                       "destination_id", "profile_id", "campaign_id", "impression_id", "route_id",
                                       "surface", "interest")] +
              [("synthetic", BOOL), ("schema_version", INT), ("event_sequence", INT), ("selected", BOOL),
               ("visible_fraction", FLOAT), ("visible_ms", INT), ("place_ids", LIST), ("stops", INT)],
    "campaign_metrics": GROUP + CTR,
    "ctr_daily": GROUP + [("day_utc", TEXT)] + CTR,
    "ctr_cells": GROUP + [("day_utc", TEXT), ("profile_id", TEXT), ("destination_id", TEXT)] + CTR,
    "route_state": ACTOR + [("route_id", TEXT)],
    "favorite_state": ACTOR,
    "state_actions": ACTOR + [("route_id", TEXT), ("event_type", TEXT)],
    "profiles": [("profile_id", TEXT)] + METRICS,
    "regions": [("region", TEXT)] + METRICS,
    "destinations": [("destination_id", TEXT), ("id", TEXT), ("name", TEXT), ("region", TEXT), ("interests", LIST)] + METRICS,
    "interests": [("interest", TEXT), ("selected", INT), ("deselected", INT)],
    "controls": [("destination_id", TEXT)] + OPERATING,
    "decisions": DECISION + [("digital_click_actions", INT)],
    "decision_history": DECISION + [("trigger_revision", INT), ("trigger_case", TEXT)],
}


def file_sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, sort_keys=True, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def historical_context(path):
    if path is None or not Path(path).is_file():
        return {"available": False, "label": "[SIN_DATOS] Histórico oficial fuera de este corte"}
    path = Path(path)
    before = file_sha(path)
    sources = {}
    with duckdb.connect(str(path), read_only=True, config={"threads": 2}) as db:
        queries = {
            "INAH": ("fact_inah_visits_monthly", "site_id", "entradas registradas por recinto-mes"),
            "DataTur": ("fact_datatur_occupancy_monthly", "center_id", "porcentaje hotelero del centro monitoreado por mes"),
        }
        for source, (relation, key, unit) in queries.items():
            rows, first, last, entities = db.execute(
                f"SELECT count(*), min(period)::VARCHAR, max(period)::VARCHAR, count(DISTINCT {key}) FROM {relation}"
            ).fetchone()
            sources[source] = {"relation": relation, "rows": rows, "first_period": first, "last_period": last,
                               "entities": entities, "unit": unit}
    after = file_sha(path)
    if before != after:
        raise RuntimeError("El histórico oficial cambió durante la lectura")
    return {"available": True, "label": "[OBSERVADO] Contexto oficial, lectura separada", "sha256": before,
            "database_name": path.name, "sources": sources}


def compare_db(path, metrics, expected_events):
    with duckdb.connect(str(path), read_only=True, config={"threads": 2}) as db:
        ledger = db.execute("SELECT * FROM quality_summary").fetchone()
        if ledger != (expected_events, expected_events, int(expected_events > 0), 0):
            raise RuntimeError("El registro SQL no coincide con el corte CRM")
        state = dict(db.execute("SELECT entity, active_elements FROM state_summary").fetchall())
        if state != {key: values["active"] for key, values in metrics["state_totals"].items()}:
            raise RuntimeError("El estado final en SQL difiere del reductor")
        if tuple(metrics["recommendations"][key] for key in ("lists", "items_shown", "saved_actions")) != db.execute(
            "SELECT * FROM recommendation_summary"
        ).fetchone():
            raise RuntimeError("Las recomendaciones en SQL difieren del reductor")
        if db.execute("SELECT count(*) FROM ctr_reconciliation WHERE NOT reconciles").fetchone()[0]:
            raise RuntimeError("Numeradores y denominadores SQL no concilian")
        if db.execute("SELECT count(*) FROM decisions WHERE automatic_increase").fetchone()[0]:
            raise RuntimeError("Se detectó promoción automática no autorizada")


def publish(snapshot, catalog, run_id, output, as_of, seed=None, historical=None):
    if not is_run_id(run_id):
        raise ValueError("Identificador de corrida inválido")
    reduce_started = time.perf_counter()
    projection = reduce_events(snapshot["events"], catalog, snapshot["controls"], as_of, run_id)
    elapsed_reduce = (time.perf_counter() - reduce_started) * 1_000
    positions = snapshot["positions"]
    audit = snapshot["audit"]
    catalog_hash = logical_hash(catalog)
    history = historical_context(historical)
    cut_id = logical_hash({"hashes": projection["hashes"], "positions": positions, "catalog": catalog_hash,
                           "as_of": projection["as_of"], "version": FORMAT_VERSION, "seed": seed,
                           "history": history.get("sha256")})[:24]
    destination = Path(output) / run_id / cut_id
    if destination.is_dir():
        return verify_manifest(destination / "manifest.json")
    destination.parent.mkdir(parents=True, exist_ok=True)
    identifiers = {"simulation_run_id": run_id, "cut_id": cut_id}
    with tempfile.TemporaryDirectory(prefix=".export-", dir=destination.parent) as staging_name:
        staging = Path(staging_name)
        table_info = {}
        core = staging / "crm.duckdb"
        with duckdb.connect(str(core), config={"threads": 2}) as db:
            for name, schema in SCHEMAS.items():
                rows = projection["tables"][name]
                parquet = staging / f"{name}.parquet"
                arrow_schema = pa.schema(COMMON + schema, metadata={b"crm_export_version": b"1", b"provenance": b"SIMULADO"})
                values = pa.Table.from_pylist([{**row, **identifiers} for row in rows], schema=arrow_schema)
                pq.write_table(values, parquet, compression="zstd")
                db.execute(f'CREATE TABLE "{name}" AS SELECT * FROM read_parquet(?)', [str(parquet)])
                table_info[name] = {"file": parquet.name, "rows": len(rows), "logical_sha256": logical_hash(rows),
                                    "schema": {field.name: str(field.type) for field in arrow_schema}}
            db.execute((DIRECTORY / "queries.sql").read_text(encoding="utf-8"))
        query_started = time.perf_counter()
        compare_db(core, projection["metrics"], len(projection["tables"]["events"]))
        elapsed_queries = (time.perf_counter() - query_started) * 1_000
        integrity_conflicts = audit.get("counts", {}).get("conflict", 0) + projection["metrics"]["quality"]["canonical_id_conflicts"]
        indicator = {**identifiers, "as_of": projection["as_of"], "label": LABEL, "metrics": projection["metrics"],
                     "monitor": audit, "policies": projection["tables"]["decisions"],
                     "policy_history": projection["tables"]["decision_history"], "history": history,
                     "positions": positions, "hashes": projection["hashes"]}
        write_json(staging / "indicators.json", indicator)
        files = {path.name: {"sha256": file_sha(path), "bytes": path.stat().st_size}
                 for path in sorted(staging.iterdir()) if path.is_file()}
        manifest = {**identifiers, "version": FORMAT_VERSION, "schema_version": 1, "as_of": projection["as_of"],
                    "published_at": stamp(datetime.now(timezone.utc)), "timezone": "UTC", "label": LABEL,
                    "reducer_version": projection["reducer_version"], "seed": seed, "positions": positions,
                    "hashes": {**projection["hashes"], "catalog": catalog_hash}, "tables": table_info, "files": files,
                    "historical_context": history, "query_ms": elapsed_queries, "reduce_ms": elapsed_reduce,
                    "integrity": "conflictive" if integrity_conflicts else "reconciled",
                    "integrity_conflicts": integrity_conflicts}
        write_json(staging / "manifest.json", manifest)
        try:
            os.rename(staging, destination)
        except OSError as error:
            if error.errno not in {errno.EEXIST, errno.ENOTEMPTY} or not destination.is_dir():
                raise
            return verify_manifest(destination / "manifest.json")
    return manifest


def verify_manifest(path):
    path = Path(path)
    manifest = json.loads(path.read_text(encoding="utf-8"))
    if manifest["version"] != FORMAT_VERSION or manifest["schema_version"] != 1:
        raise ValueError("Versión de exportación no soportada")
    if set(manifest["tables"]) != SCHEMAS.keys():
        raise ValueError("El manifiesto no contiene todas las tablas del corte")
    required_files = {"crm.duckdb", "indicators.json"} | {f"{name}.parquet" for name in SCHEMAS}
    if set(manifest["files"]) != required_files:
        raise ValueError("Inventario de archivos incompleto")
    for name, metadata in manifest["files"].items():
        item = path.parent / name
        if not item.is_file() or item.stat().st_size != metadata["bytes"] or file_sha(item) != metadata["sha256"]:
            raise ValueError(f"El artefacto no concuerda con el manifiesto: {name}")
    indicator = json.loads((path.parent / "indicators.json").read_text(encoding="utf-8"))
    if any(indicator[k] != manifest[k] for k in ("simulation_run_id", "cut_id", "as_of", "positions")) or any(
            indicator["hashes"].get(k) != manifest["hashes"][k] for k in ("controls", "corpus", "results")):
        raise ValueError("Indicadores y manifiesto pertenecen a cortes diferentes")
    for name, info in manifest["tables"].items():
        if name not in SCHEMAS or info["file"] != f"{name}.parquet":
            raise ValueError(f"Tabla fuera del contrato del corte: {name}")
        parquet = pq.ParquetFile(path.parent / info["file"])
        expected = pa.schema(COMMON + SCHEMAS[name])
        if not parquet.schema_arrow.equals(expected) or info["schema"] != {f.name: str(f.type) for f in expected}:
            raise ValueError(f"Esquema incompatible para {name}")
        rows = parquet.read()
        if len(rows) != info["rows"] or any(
            len(rows) and rows.column(key).unique().to_pylist() != [manifest[key]]
            for key in ("simulation_run_id", "cut_id")
        ):
            raise ValueError(f"La tabla mezcla cortes o difiere del recuento: {name}")
        logical = rows.drop(["cut_id"] if name in {"events", "controls"} else ["cut_id", "simulation_run_id"]).to_pylist()
        if name == "events":
            logical = [{key: value for key, value in row.items() if value is not None} for row in logical]
        if logical_hash(logical) != info["logical_sha256"]:
            raise ValueError(f"El contenido lógico no concuerda con el manifiesto: {name}")
    core = path.parent / "crm.duckdb"
    with duckdb.connect(str(core), read_only=True, config={"threads": 2}) as db:
        for name in SCHEMAS:
            file_path = str(path.parent / f"{name}.parquet")
            table = f'SELECT * FROM "{name}"'
            mirror = "SELECT * FROM read_parquet(?)"
            for left, right in ((table, mirror), (mirror, table)):
                if db.execute(f"SELECT EXISTS (SELECT * FROM ({left} EXCEPT ALL {right}) AS delta)", [file_path]).fetchone()[0]:
                    raise ValueError(f"DuckDB y Parquet difieren en {name}")
    compare_db(core, indicator["metrics"], manifest["tables"]["events"]["rows"])
    return manifest


def main():
    parser = argparse.ArgumentParser(description="Versionar o verificar exportaciones del CRM turístico sintético")
    parser.add_argument("--run-id")
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--as-of", help="Fecha UTC fija para verificación de replay")
    parser.add_argument("--seed", type=int)
    parser.add_argument("--historical-db", type=Path)
    parser.add_argument("--verify", type=Path, help="Verificar un manifest.json con un proceso independiente")
    args = parser.parse_args()
    if args.verify:
        result = verify_manifest(args.verify)
        result["manifest_path"] = str(args.verify)
    else:
        if not is_run_id(args.run_id):
            parser.error("--run-id debe identificar una corrida válida")
        from store import Store

        read_started = time.perf_counter()
        store = Store()
        try:
            snapshot = store.read_snapshot(args.run_id, include_deliveries=False)
        finally:
            store.close()
        read_ms = (time.perf_counter() - read_started) * 1_000
        result = publish(snapshot, load_catalog(), args.run_id, args.output, args.as_of or datetime.now(timezone.utc),
                         args.seed, args.historical_db)
        result["read_ms"] = read_ms
        result["manifest_path"] = str(args.output / args.run_id / result["cut_id"] / "manifest.json")
    print(canonical_json(result))


if __name__ == "__main__":
    main()
