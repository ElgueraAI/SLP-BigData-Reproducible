"""Read the broker's high watermarks and durable next offsets without joining the consumer."""
import json
import os
from confluent_kafka import Consumer, TopicPartition
from contracts import EVENT_TOPIC, QUARANTINE_TOPIC


def positions():
    reader = Consumer({"bootstrap.servers": os.getenv("KAFKA_BOOTSTRAP","broker:9092"),
                       "group.id": os.getenv("KAFKA_GROUP_ID","crm-v1"), "enable.auto.commit": False})
    try:
        metadata = reader.list_topics(timeout=8)
        keys = [TopicPartition(name, p) for name in (EVENT_TOPIC, QUARANTINE_TOPIC)
                for p in sorted(metadata.topics[name].partitions)]
        result = {}
        for key in reader.committed(keys, timeout=8):
            low, end = reader.get_watermark_offsets(key,timeout=8)
            committed = key.offset if key.offset >= 0 else low
            result[f"{key.topic}/{key.partition}"] = {"start":low,"committed":committed,"end":end,
                                                       "lag":max(0,end-committed)}
        return result
    finally:
        reader.close()


if __name__ == "__main__":
    print(json.dumps(positions()))
