"""Construir el cuaderno portable con los agregados verificados del expediente elegido."""
import json
import sys
from pathlib import Path
import nbformat as nb

directory = Path(__file__).resolve().parent
source = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
cells = []
md = lambda value: cells.append(nb.v4.new_markdown_cell(value))
code = lambda value: cells.append(nb.v4.new_code_cell(value))
md("""# Big Data 04 · CRM turístico de San Luis Potosí
**ENTORNO ACADÉMICO — DATOS SINTÉTICOS**  
Universidad Rosario Castellanos · Ciencias de Datos para Negocios · Semestre 2026-2

Este cuaderno reconstruye ocho gráficas a partir de mediciones de Kafka y MongoDB. Cada fila corresponde a una corrida local completa. Las cifras de interacción proceden del simulador. En Colab se puede ejecutar todo desde el menú **Entorno de ejecución**. El archivo ya incluye la exportación agregada que acompaña al informe.""")
md("""## Arquitectura, datos y contrato
El simulador toma destinos publicados y los ocho perfiles editoriales. Emite acciones por HTTP con una semilla. La API verifica la versión y el catálogo y espera el acuse de Kafka. El consumidor registra el evento canónico, su posición y las incidencias en MongoDB antes de confirmar el siguiente offset. El mismo reductor genera estados y atribución al recibir eventos y al reconstruir el corte. Parquet y DuckDB fijan las tablas exportadas. INAH y DataTur conservan sus granos recinto–mes y centro hotelero–mes.

La identidad del evento es estable al reenviarlo. La secuencia de cada actor ordena altas y bajas. Se considera elegible la exposición con al menos 50 % visible durante 1 000 ms continuos. Un clic exige correspondencia de impresión, actor, sesión, destino, campaña y familia. El periodo corresponde al tiempo de la impresión.""")
code("import json\nfrom pathlib import Path\nimport pandas as pd\nimport matplotlib.pyplot as plt\nfrom IPython.display import display\n\n# Opcional: coloque un archivo measurements.json autorizado junto al cuaderno.\npath = Path('measurements.json')\nembedded = json.loads("+repr(json.dumps(source,ensure_ascii=False,separators=(",",":")))+")\nexperiment = json.loads(path.read_text(encoding='utf-8')) if path.is_file() else embedded\nruns = sorted(experiment['runs'], key=lambda row: row['count'])\nassert [r['count'] for r in runs] == [1000, 10000, 100000]\nprint(experiment['label'])\ndisplay(pd.DataFrame([{k:r[k] for k in ('run','seed','count','cut','at')} for r in runs]))")
md("""## Calidad e idempotencia
La conciliación parte de los intentos publicados. Un rechazo de contrato queda en cuarentena. Una entrega aceptada puede repetir la identidad de un evento previo. El indicador de tardanza compara el tiempo de evento con el máximo anterior de su partición y la tolerancia de cinco segundos. Se verifica la conservación del corpus antes de graficarlo.""")
code("""for r in runs:
    assert r['accepted'] + r['rejected'] == r['count']
    assert r['unique'] + r['duplicates'] == r['accepted'] and r['errors'] == 0
    assert r['final_lag'] == 0 and r['unique'] == r['latency_ms']['n']
display(pd.DataFrame([{k:r[k] for k in ('count','unique','duplicates','rejected','late_new','final_lag')} for r in runs]))""")
md("""### Verificación opcional del corte Parquet
Para reconciliar el corpus original, coloque la carpeta de un corte autorizado en `export/` en la sesión. Se comprueban las huellas del manifiesto y la unicidad de cada evento antes de consultar las tablas. En la modalidad autónoma se usan los agregados con las huellas del corte.""")
code("""import hashlib
folder = Path('export')
if (folder / 'manifest.json').is_file():
    m = json.loads((folder/'manifest.json').read_text(encoding='utf-8'))
    r = next(row for row in runs if row['run'] == m['simulation_run_id'] and row['cut'] == m['cut_id'])
    assert m['hashes'] == r['hashes']
    for name, info in m['files'].items():
        assert Path(name).name == name
        assert hashlib.sha256((folder/name).read_bytes()).hexdigest() == info['sha256']
    ev = pd.read_parquet(folder/'events.parquet', columns=['simulation_run_id','event_id','cut_id'])
    assert ev['simulation_run_id'].unique().tolist() == [r['run']]
    assert ev['cut_id'].unique().tolist() == [r['cut']]
    assert len(ev) == ev['event_id'].nunique() == r['unique']
    display(pd.read_parquet(folder/'campaign_metrics.parquet'))
else:
    print('Modo autónomo con agregados de las tres corridas y hashes registrados.')""")
md("""## Rendimiento y escalabilidad
El rendimiento activo divide eventos únicos por tiempo activo del consumidor. El rendimiento extremo a extremo incluye la publicación y el drenaje, y en la corrida de recuperación también la pausa controlada. La latencia física parte del sello real de la API y termina al persistir el evento. Los percentiles usan interpolación lineal. Las tres escalas se midieron una vez en un nodo; la variabilidad entre réplicas queda abierta.""")
code("""labels = [f"{r['count']:,}" for r in runs]
x = range(len(labels))
def count_chart(values, title, unit):
    fig, ax = plt.subplots(figsize=(6.5, 3.1), layout='constrained')
    bars = ax.bar(labels, values, color='#216b77')
    ax.bar_label(bars, fmt='%.0f', padding=3)
    ax.margins(y=.17)
    ax.set(title=title, xlabel='Intentos por corrida', ylabel=unit)
    plt.show()
count_chart([r['throughput_active'] for r in runs], 'Rendimiento durante el consumo activo', 'Eventos únicos/s')""")
code("""fig, ax = plt.subplots(figsize=(6.5,3.4), layout='constrained')
for metric in ('mean','p50','p95','p99'):
    ax.plot(labels, [r['latency_ms'][metric] for r in runs], 'o-', label=metric)
ax.set(title='Latencia desde la recepción hasta MongoDB', ylabel='Milisegundos', xlabel='Intentos por corrida')
ax.legend(); plt.show()""")
code("""count_chart([r['unique'] for r in runs], 'Eventos canónicos persistidos', 'Eventos únicos')""")
code("""count_chart([r['rejected'] for r in runs], 'Rechazos de contrato en cuarentena', 'Intentos')""")
code("""count_chart([r['duplicates'] for r in runs], 'Retransmisiones descartadas', 'Entregas duplicadas')""")
md("""## Recuperación y reproducción
El consumidor se detuvo después de persistir un prefijo. El productor continuó publicando. Al reiniciar, Kafka reentregó lo pendiente. La suma de diferencias entre la posición final y la confirmada mide el rezago. Los hashes de corpus y resultados del manifiesto permiten contrastar el replay independiente al mismo instante de decisión.""")
code("""r = next(r for r in runs if r['recovery_s'] is not None)
lag = r['recovery_lag']
assert lag['during'] > 0 and lag['after'] == 0
fig, ax = plt.subplots(figsize=(6.5,3), layout='constrained')
ax.bar(['Antes', 'Detenido', 'Recuperado'], [lag[k] for k in ('before','during','after')], color=['#216b77','#b46133','#216b77'])
ax.set(title=f"Recuperación observada en {r['recovery_s']:.2f} s", ylabel='Offsets pendientes')
plt.show()
display(pd.DataFrame([{'corrida':z['run'], **z['hashes']} for z in runs]))""")
md("""## CRM y aplicación a campaña
El CTR divide impresiones elegibles con uno o más clics válidos entre impresiones elegibles. Un denominador vacío queda sin estimación. La comparación mantiene separadas la pauta y la tarjeta editorial. Las acciones de alta y baja se distinguen del estado activo final de cada ruta y favorito.""")
code("""largest = runs[-1]
ads = pd.DataFrame([m for m in largest['campaign_metrics'] if m['family']=='campaign'])
assert (ads['clicked_impressions'] <= ads['eligible_impressions']).all()
display(ads)
ax = ads.plot.bar(x='campaign_id', y='ctr_pct', legend=False, color='#216b77', rot=0)
ax.set(title='CTR simulado por campaña · corrida mayor', xlabel='Campaña', ylabel='% de impresiones elegibles')
plt.tight_layout(); plt.show()
display(pd.DataFrame(largest['states']).T)""")
md("""## Sustentabilidad y limitaciones
La elegibilidad exige fuente operativa simulada verificada, acceso abierto, ambiente adecuado, vigencia y al menos una plaza libre. H07 tiene cupo agotado. H06 comienza como candidato a revisión y cambia a pausa con la revisión D. Los destinos sin revisión conservan el estado sin datos. El ranking digital sirve para decidir qué creatividad ensayar después de verificar el destino. La reducción de presión turística y el retorno publicitario requerirían medición independiente en campo.""")
code("""states = pd.Series(largest['policy_counts'], dtype=int)
ax = states.plot.barh(color='#216b77')
ax.set(title='Estado de promoción en el último corte', xlabel='Destinos del catálogo')
plt.tight_layout(); plt.show()
display(pd.DataFrame(largest['policy_history'])[['destination_id','trigger_case','revision','capacity','reservations','status','reason']])""")
book=nb.v4.new_notebook(cells=cells,metadata={"kernelspec":{"name":"python3","display_name":"Python 3","language":"python"}})
nb.validate(book)
nb.write(book,directory/"UCA01_BigData04_Kappa_CRM_SLP.ipynb")
