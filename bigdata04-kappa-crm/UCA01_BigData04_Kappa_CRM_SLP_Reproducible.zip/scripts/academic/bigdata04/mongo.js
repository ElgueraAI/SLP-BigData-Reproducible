// This program accepts only the JSON operations listed below. No input is evaluated as code.
const stream = require("node:process");
const lines = require("node:readline").createInterface({ input: stream.stdin, terminal: false });
const demo = db.getSiblingDB(databaseName);
const events = demo.getCollection("events");
const deliveries = demo.getCollection("deliveries");
const controls = demo.getCollection("destination_constraints_demo");
const quarantine = demo.getCollection("quarantine");
const consumerState = demo.getCollection("consumer_state");
const cuts = demo.getCollection("projection_cuts");
const faults = demo.getCollection("fault_injections");
const EVENT_TOPIC = "crm.events.v1";
const WRITE = { writeConcern: { w: 1, j: true } };
const STATE_KEY = { _id: "input" };

function deliveryId(position) {
    return JSON.stringify([position.topic, position.partition, position.offset]);
}

async function initialize() {
    await events.createIndex({ simulation_run_id: 1, partition: 1, offset: 1 });
    await events.createIndex({ simulation_run_id: 1, event_type: 1, event_time: 1 });
    await events.createIndex({ simulation_run_id: 1, demo_actor_id: 1, event_sequence: 1 });
    await deliveries.createIndex({ simulation_run_id: 1, topic: 1, partition: 1, offset: 1 });
    await controls.createIndex({ simulation_run_id: 1, destination_id: 1, revision: 1 }, { unique: true });
    await quarantine.createIndex({ simulation_run_id: 1, stage: 1, partition: 1, offset: 1 });
    return true;
}

async function getState() {
    return await consumerState.findOne(STATE_KEY) || {};
}

function positionOf(row) {
    return { topic: row.topic, partition: row.partition, offset: row.offset };
}

function makeRejected(row, priorWatermark, stamp) {
    const rowPosition = positionOf(row);
    return {
        _id: deliveryId(rowPosition), ...rowPosition,
        simulation_run_id: row.quarantine.simulation_run_id,
        classification: "rejected",
        reason: row.quarantine.reason,
        quarantine: row.quarantine,
        quarantined: false,
        persisted_at: stamp,
        watermark: priorWatermark,
        late: false,
    };
}

function makeDelivery(row, canonical, watermark, tolerance, stamp) {
    const rowPosition = positionOf(row);
    const event = row.event;
    const samePosition = canonical.topic === row.topic
        && canonical.partition === row.partition && canonical.offset === row.offset;
    const classification = canonical.fingerprint !== row.fingerprint
        ? "conflict" : (samePosition ? "new" : "duplicate");
    const timestamp = Date.parse(event.event_time);
    const late = watermark !== null && timestamp < Date.parse(watermark) - tolerance;
    const maxObserved = watermark === null || event.event_time > watermark
        ? event.event_time : watermark;
    const persisted = classification === "new" ? canonical.persisted_at : stamp;
    const result = {
        _id: deliveryId(rowPosition), ...rowPosition,
        simulation_run_id: event.simulation_run_id,
        event_id: event.event_id,
        classification, late, watermark: maxObserved,
        event_time: event.event_time,
        received_at: event.received_at,
        persisted_at: persisted,
        latency_ms: classification === "new" ? Date.parse(persisted) - Date.parse(event.received_at) : null,
    };
    if (classification === "conflict") {
        result.reason = "identity_conflict";
        result.quarantined = false;
        result.quarantine = {
            stage: "consumer", reason: result.reason, simulation_run_id: event.simulation_run_id,
            recorded_at: stamp, ...rowPosition,
        };
    }
    return result;
}

async function persistBatch(request) {
    const started = Date.now();
    const state = await getState();
    const { rows, api_rejections: api, late_tolerance_ms: tolerance } = request;
    const rowIds = rows.map(deliveryId);
    const existing = new Map(
        (rowIds.length ? await deliveries.find({ _id: { $in: rowIds } }).toArray() : [])
            .map(item => [item._id, item])
    );
    // The first upsert stores the origin offset and body. A replay repairs a missing delivery.
    const candidates = new Map();
    for (const row of rows) {
        if (row.event && !existing.has(deliveryId(row)) && !candidates.has(row.event.event_id)) {
            candidates.set(row.event.event_id, row);
        }
    }
    if (candidates.size) {
        await events.bulkWrite([...candidates.values()].map(row => ({
            updateOne: {
                filter: { _id: row.event.event_id },
                update: { $setOnInsert: { ...row.event, ...positionOf(row), fingerprint: row.fingerprint } },
                upsert: true,
            },
        })), { ...WRITE, ordered: false });
    }
    // Stamp the common instant when the event bulk write has acknowledged journaling.
    const stamp = new Date().toISOString();
    const candidateIds = [...candidates.keys()];
    if (candidates.size) {
        await events.updateMany(
            { _id: { $in: candidateIds }, persisted_at: { $exists: false } },
            { $set: { persisted_at: stamp } }, WRITE,
        );
    }
    const canonical = new Map(
        (candidates.size
            ? await events.find(
                { _id: { $in: candidateIds } },
                { topic: 1, partition: 1, offset: 1, fingerprint: 1, persisted_at: 1 },
            ).toArray()
            : []
        ).map(event => [event._id, event])
    );
    const positions = { ...(state.partition_state || {}) };
    const ledger = [];
    const pendingQuarantine = [];
    let replays = 0;
    for (const row of rows) {
        const key = String(row.partition);
        const prior = positions[key] || { next_offset: 0, watermark: null };
        let entry = existing.get(deliveryId(row));
        if (entry) {
            replays += 1;
        } else {
            entry = row.event
                ? makeDelivery(row, canonical.get(row.event.event_id), prior.watermark, tolerance, stamp)
                : makeRejected(row, prior.watermark, stamp);
            ledger.push(entry);
        }
        if (row.offset >= prior.next_offset) {
            positions[key] = { next_offset: row.offset + 1, watermark: entry.watermark };
        }
        if (entry.quarantine && !entry.quarantined) {
            pendingQuarantine.push({ delivery_id: entry._id, record: entry.quarantine });
        }
    }
    if (ledger.length) {
        await deliveries.bulkWrite(ledger.map(entry => ({
            updateOne: {
                filter: { _id: entry._id }, update: { $setOnInsert: entry }, upsert: true,
            },
        })), { ...WRITE, ordered: false });
    }
    if (api.length) {
        await quarantine.bulkWrite(api.map(row => {
            const _id = deliveryId(row);
            return {
                updateOne: {
                    filter: { _id },
                    update: { $setOnInsert: { ...row.quarantine, ...positionOf(row), persisted_at: stamp } },
                    upsert: true,
                },
            };
        }), { ...WRITE, ordered: false });
    }
    return { positions, pending_quarantine: pendingQuarantine, replays, persistence_ms: Date.now() - started };
}

async function completeBatch(request) {
    const { positions, quarantine_positions, acknowledged_quarantine_ids, telemetry } = request;
    if (acknowledged_quarantine_ids.length) {
        await deliveries.updateMany(
            { _id: { $in: acknowledged_quarantine_ids } }, { $set: { quarantined: true } }, WRITE,
        );
    }
    const committedFields = {
        partition_state: positions,
        status: "running",
        heartbeat: new Date().toISOString(),
    };
    if (telemetry) {
        committedFields.last_batch = telemetry;
    }
    const updates = { $set: committedFields };
    if (Object.keys(quarantine_positions).length) {
        updates.$max = Object.fromEntries(Object.entries(quarantine_positions)
            .map(([partition, next]) => ["quarantine_positions." + partition, next]));
    }
    if (telemetry?.replays) {
        updates.$inc = { replay_attempts: telemetry.replays };
    }
    if (telemetry) {
        updates.$inc = {
            ...(updates.$inc || {}),
            "totals.batches": 1,
            "totals.active_ms": telemetry.active_ms,
            "totals.validation_ms": telemetry.validation_ms,
            "totals.persistence_ms": telemetry.persistence_ms,
            "totals.input_attempts": telemetry.input_attempts,
        };
    }
    await consumerState.updateOne(STATE_KEY, updates, { ...WRITE, upsert: true });
    return true;
}

async function heartbeat(request) {
    const fields = { heartbeat: new Date().toISOString(), status: request.status };
    if (request.committed_positions !== null) {
        fields.committed_positions = request.committed_positions;
    }
    if (request.log_end_offsets !== null) {
        fields.log_end_offsets = request.log_end_offsets;
    }
    if (request.late_tolerance_ms !== null) {
        fields.late_tolerance_ms = request.late_tolerance_ms;
    }
    await consumerState.updateOne(STATE_KEY, { $set: fields }, { ...WRITE, upsert: true });
    return true;
}

async function putControl(request) {
    const control = request.control;
    const _id = JSON.stringify([control.simulation_run_id, control.destination_id, control.revision]);
    const insertion = await controls.updateOne(
        { _id }, { $setOnInsert: { ...control, fingerprint: request.fingerprint } }, { ...WRITE, upsert: true },
    );
    if (insertion.upsertedCount) {
        return true;
    }
    const prior = await controls.findOne({ _id }, { fingerprint: 1 });
    if (prior.fingerprint !== request.fingerprint) {
        const error = new Error();
        error.safeCode = "control_conflict";
        throw error;
    }
    return false;
}

function globalPositions(state) {
    return Object.fromEntries(Object.entries(state.partition_state || {}).map(([key, value]) => [key, value.next_offset]));
}

async function runPositions(run, state) {
    const global = globalPositions(state);
    const entries = await Promise.all(Object.entries(global).map(async ([key, next]) => {
        const matches = await deliveries.find({
            simulation_run_id: run, topic: EVENT_TOPIC, partition: Number(key), offset: { $lt: next },
        }, { offset: 1 }).sort({ offset: -1 }).limit(1).toArray();
        return [key, matches.length ? matches[0].offset + 1 : 0];
    }));
    return Object.fromEntries(entries.filter(([, value]) => value > 0));
}

function positioned(run, positions) {
    return {
        simulation_run_id: run,
        topic: EVENT_TOPIC,
        $or: Object.entries(positions).map(([key, next]) => ({ partition: Number(key), offset: { $lt: next } })),
    };
}

async function readEvents(run, positions) {
    if (!Object.keys(positions).length) {
        return [];
    }
    return await events.find(positioned(run, positions)).sort({ partition: 1, offset: 1 }).toArray();
}

async function readDeliveries(run, positions, summaryOnly = false) {
    if (!Object.keys(positions).length) {
        return [];
    }
    const projection = summaryOnly ? { _id: 0, classification: 1, late: 1, latency_ms: 1 } : { quarantine: 0 };
    const cursor = deliveries.find(positioned(run, positions), projection);
    if (!summaryOnly) {
        cursor.sort({ partition: 1, offset: 1 });
    }
    return await cursor.toArray();
}

async function readControls(run) {
    return await controls.find({ simulation_run_id: run }, { fingerprint: 0 }).sort({
        destination_id: 1, revision: 1,
    }).toArray();
}

function auditContext(state, positions) {
    const committed = state.committed_positions || {};
    const logEnd = state.log_end_offsets || {};
    const lag = {};
    for (const [partition, offset] of Object.entries(logEnd)) {
        if (partition in committed) {
            lag[partition] = Math.max(0, offset - committed[partition]);
        }
    }
    return {
        status: state.status || "starting",
        heartbeat: state.heartbeat || null,
        positions,
        durable_positions: globalPositions(state),
        committed_positions: committed,
        log_end_offsets: logEnd,
        lag,
        late_tolerance_ms: state.late_tolerance_ms ?? null,
        last_batch: state.last_batch || null,
        replay_attempts: state.replay_attempts || 0,
        totals: state.totals || {},
    };
}

function countSummary(rows) {
    const counts = { new: 0, duplicate: 0, conflict: 0, rejected: 0, late: 0, late_new: 0, deliveries: rows.length };
    const latencies = [];
    for (const row of rows) {
        counts[row.classification] += 1;
        if (row.late) {
            counts.late += 1;
            if (row.classification === "new") {
                counts.late_new += 1;
            }
        }
        if (row.classification === "new" && Number.isFinite(row.latency_ms)) {
            latencies.push(row.latency_ms);
        }
    }
    latencies.sort((left, right) => left - right);
    function quantile(fraction) {
        const rank = (latencies.length - 1) * fraction;
        const low = Math.floor(rank);
        const high = Math.ceil(rank);
        return latencies[low] + (latencies[high] - latencies[low]) * (rank - low);
    }
    const n = latencies.length;
    return {
        counts,
        latency_ms: {
            n, mean: n ? latencies.reduce((a, b) => a + b, 0) / n : null,
            p50: n ? quantile(0.50) : null, p95: n ? quantile(0.95) : null,
            p99: n ? quantile(0.99) : null, method: "linear_interpolation",
        },
    };
}

async function quarantineCount(run, state) {
    const query = quarantineQuery(run, state);
    return query ? await quarantine.countDocuments(query) : 0;
}

function quarantineQuery(run, state) {
    const partitions = Object.entries(state.quarantine_positions || {});
    if (!partitions.length) {
        return null;
    }
    return {
        simulation_run_id: run, stage: "api",
        $or: partitions.map(([partition, next]) => ({ partition: Number(partition), offset: { $lt: next } })),
    };
}

async function readProgress(request) {
    const run = request.run;
    const state = await getState();
    const [positions, controlCount, acceptedRejections] = await Promise.all([
        runPositions(run, state),
        controls.countDocuments({ simulation_run_id: run }),
        quarantineCount(run, state),
    ]);
    return {
        ...auditContext(state, positions), control_count: controlCount, quarantine_count: acceptedRejections,
    };
}

async function readAudit(request) {
    const progress = await readProgress(request);
    const rows = await readDeliveries(request.run, progress.positions, true);
    return { ...progress, ...countSummary(rows) };
}

async function readSnapshot(request) {
    const run = request.run;
    const state = await getState();
    const positions = await runPositions(run, state);
    const canonical = await readEvents(run, positions);
    const ledger = await readDeliveries(run, positions, !request.include_deliveries);
    const revisions = await readControls(run);
    const audit = {
        ...auditContext(state, positions), ...countSummary(ledger),
        control_count: revisions.length, quarantine_count: await quarantineCount(run, state),
    };
    return { positions, events: canonical, deliveries: request.include_deliveries ? ledger : [], controls: revisions, audit };
}

async function readWithPositions(request, reader) {
    const state = await getState();
    if (!request.positions) {
        return await reader(request.run, await runPositions(request.run, state));
    }
    const durable = globalPositions(state);
    const positions = Object.fromEntries(Object.entries(request.positions)
        .filter(([key]) => key in durable)
        .map(([key, next]) => [key, Math.min(next, durable[key])]));
    return await reader(request.run, positions);
}

async function listRuns() {
    const state = await getState();
    const candidates = await deliveries.distinct("simulation_run_id");
    const controlRuns = await controls.distinct("simulation_run_id");
    const quarantineRuns = await quarantine.distinct("simulation_run_id", { stage: "api" });
    const runs = [...new Set([...candidates, ...controlRuns, ...quarantineRuns])].filter(value => typeof value === "string");
    const ranked = [];
    for (const run of runs) {
        const positions = await runPositions(run, state);
        const activity = [];
        if (Object.keys(positions).length) {
            const recent = await deliveries.find(positioned(run, positions), { persisted_at: 1 })
                .sort({ persisted_at: -1 }).limit(1).toArray();
            activity.push(recent[0].persisted_at);
        }
        const recentControls = await controls.find({ simulation_run_id: run }, { recorded_at: 1 })
            .sort({ recorded_at: -1 }).limit(1).toArray();
        if (recentControls.length) {
            activity.push(recentControls[0].recorded_at);
        }
        const query = quarantineQuery(run, state);
        const recentRejections = query ? await quarantine.find(query, { persisted_at: 1 })
            .sort({ persisted_at: -1 }).limit(1).toArray() : [];
        if (recentRejections.length) {
            activity.push(recentRejections[0].persisted_at);
        }
        if (activity.length) {
            ranked.push([run, activity.sort().at(-1)]);
        }
    }
    return ranked.sort((left, right) => right[1].localeCompare(left[1]) || left[0].localeCompare(right[0]))
        .map(([run]) => run);
}

async function triggerOnce(request) {
    const insertion = await faults.updateOne(
        { _id: request.marker }, { $setOnInsert: { triggered_at: new Date().toISOString() } },
        { ...WRITE, upsert: true },
    );
    return Boolean(insertion.upsertedCount);
}

async function publishCut(request) {
    const cut = { ...request.cut, _id: request.run, published_at: new Date().toISOString() };
    const result = await cuts.updateOne({ _id: request.run }, [{
        $replaceWith: {
            $cond: [
                { $lt: [{ $ifNull: ["$as_of", ""] }, cut.as_of] },
                { $literal: cut },
                "$$ROOT",
            ],
        },
    }], { ...WRITE, upsert: true });
    return Boolean(result.modifiedCount || result.upsertedCount);
}

const operations = {
    ping: async () => Boolean((await demo.runCommand({ ping: 1 })).ok),
    initialize, persistBatch, completeBatch, heartbeat, putControl, readProgress, readAudit, readSnapshot, listRuns,
    readEvents: async request => await readWithPositions(request, readEvents),
    readDeliveries: async request => await readWithPositions(request, readDeliveries),
    readControls: async request => await readControls(request.run),
    triggerOnce, publishCut,
    readCut: async request => await cuts.findOne({ _id: request.run }, { _id: 0 }),
};

async function serve() {
    for await (const line of lines) {
        try {
            const request = JSON.parse(line);
            if (!Object.hasOwn(operations, request.op)) {
                console.log("CRM_JSON " + JSON.stringify({ ok: false, error: "invalid_operation" }));
                continue;
            }
            const value = await operations[request.op](request);
            console.log("CRM_JSON " + JSON.stringify({ ok: true, value }));
        } catch (error) {
            const code = error.safeCode || (Number.isInteger(error.code) ? "mongo_" + error.code : "mongo_operation_failed");
            console.log("CRM_JSON " + JSON.stringify({ ok: false, error: code }));
        }
    }
}

serve();
