"""Versioned operating rules for synthetic campaign decisions."""

import argparse
import json
from datetime import datetime, timedelta, timezone


RULE_VERSION = "capacity-gate-v1"
SOURCE = "synthetic-operations-v1"
MINIMUM_PLACES = 1


def utc(value):
    if isinstance(value, str):
        value = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if value.tzinfo is None or value.utcoffset() != timedelta():
        raise ValueError("Se requiere fecha ISO 8601 UTC")
    return value.astimezone(timezone.utc)


def stamp(value):
    return utc(value).isoformat(timespec="microseconds").replace("+00:00", "Z")


def select_revision(revisions, at):
    known = [revision for revision in revisions if utc(revision["recorded_at"]) <= at]
    started = [revision for revision in known if utc(revision["valid_from"]) <= at]
    latest = lambda revision: revision["revision"]
    return max(started, key=latest, default=None) or max(known, key=latest, default=None)


def evaluate(destination_id, revisions, as_of, digital_click_actions=0):
    at = utc(as_of)
    control = select_revision(revisions, at) or {}
    capacity, reservations = control.get("capacity"), control.get("reservations")
    valid_counts = type(capacity) is int and type(reservations) is int and min(capacity, reservations) >= 0
    places = capacity - reservations if valid_counts else None
    if not control:
        status, reason = "sin_datos", "sin_revision_operativa"
    elif not utc(control["valid_from"]) <= at < utc(control["valid_to"]):
        status, reason = "bloqueado", "revision_fuera_de_vigencia"
    elif control.get("verified") is not True or control.get("source") != SOURCE:
        status, reason = "bloqueado", "fuente_o_verificacion_insuficiente"
    elif (not valid_counts or type(control.get("available")) is not bool
          or control.get("access") not in {"open", "restricted", "closed"}
          or control.get("environmental_status") not in {"clear", "alert"}):
        status, reason = "bloqueado", "datos_operativos_incompletos"
    elif not control["available"]:
        status, reason = "pausa", "destino_no_disponible"
    elif control["access"] != "open":
        status, reason = "pausa", "acceso_restringido_o_cerrado"
    elif control["environmental_status"] != "clear":
        status, reason = "pausa", "alerta_ambiental"
    elif places < MINIMUM_PLACES:
        status, reason = "pausa", "cupo_insuficiente"
    else:
        status, reason = "candidato", "requiere_validacion_humana"
    fields = ("revision", "recorded_at", "valid_from", "valid_to", "source", "verified", "available", "access",
              "environmental_status")
    return {"destination_id": destination_id, "evaluated_at": stamp(at), "rule_version": RULE_VERSION,
            "status": status, "reason": reason, "case": control.get("case", "C"),
            "capacity": capacity, "reservations": reservations, "places_available": places,
            "unit": "plazas_simuladas", "minimum_places": MINIMUM_PLACES,
            "digital_click_actions": digital_click_actions, "automatic_increase": False,
            **{field: control.get(field) for field in fields}}


def project_controls(controls, destinations, digital_clicks, as_of):
    by_destination = {}
    for revision in controls:
        by_destination.setdefault(revision["destination_id"], []).append(revision)
    decisions = [evaluate(d["id"], by_destination.get(d["id"], []), as_of, digital_clicks.get(d["id"], 0))
                 for d in sorted(destinations, key=lambda item: item["id"])]
    decision_history = []
    for destination, revisions in sorted(by_destination.items()):
        for revision in sorted(revisions, key=lambda item: (utc(item["recorded_at"]), item["revision"])):
            recorded = utc(revision["recorded_at"])
            if recorded <= utc(as_of):
                decision = evaluate(destination, revisions, recorded)
                # El historial de controles conserva insumos operativos del registro; no reconstruye exposición previa.
                decision.pop("digital_click_actions")
                decision["trigger_revision"] = revision["revision"]
                decision["trigger_case"] = revision["case"]
                decision_history.append(decision)
    return decisions, decision_history


def fixture(run_id, stage, start, destination_a="H07", destination_b="H06"):
    at = utc(start)
    common = {"simulation_run_id": run_id, "recorded_at": stamp(at), "valid_from": stamp(at),
              "valid_to": stamp(at + timedelta(days=2)), "available": True, "access": "open",
              "environmental_status": "clear", "source": SOURCE, "verified": True}
    if stage == "initial":
        return [{**common, "destination_id": destination_a, "revision": 1, "capacity": 10,
                 "reservations": 10, "case": "A"},
                {**common, "destination_id": destination_b, "revision": 1, "capacity": 10,
                 "reservations": 4, "case": "B"}]
    return [{**common, "destination_id": destination_b, "revision": 2, "capacity": 4,
             "reservations": 4, "case": "D"}]


def main():
    from store import Store

    parser = argparse.ArgumentParser(description="Registrar revisiones sintéticas para el ensayo A–D")
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--stage", choices=("initial", "change"), required=True)
    parser.add_argument("--start", help="Instante UTC del cambio. Por defecto, hora de ejecución")
    parser.add_argument("--destination-a", default="H07")
    parser.add_argument("--destination-b", default="H06")
    args = parser.parse_args()
    if args.destination_a == args.destination_b:
        parser.error("los destinos de A y B deben ser distintos")
    controls = fixture(args.run_id, args.stage, args.start or datetime.now(timezone.utc),
                       args.destination_a, args.destination_b)
    store = Store()
    try:
        for control in controls:
            store.put_control(control)
    finally:
        store.close()
    print(json.dumps({"controls": controls}, ensure_ascii=False))


if __name__ == "__main__":
    main()
