-- Consultas del corte CRM. Los boletines históricos se consultan por separado en solo lectura.
CREATE VIEW campaign_summary AS
SELECT simulation_run_id, cut_id, campaign_id, eligible_impressions, clicked_impressions,
       eligible_click_actions, click_actions,
       100.0 * clicked_impressions / nullif(eligible_impressions, 0) AS ctr_pct
FROM campaign_metrics
WHERE family = 'campaign';

CREATE VIEW campaign_day_utc AS
SELECT simulation_run_id, cut_id, day_utc, campaign_id, eligible_impressions, clicked_impressions,
       eligible_click_actions, click_actions,
       100.0 * clicked_impressions / nullif(eligible_impressions, 0) AS ctr_pct
FROM ctr_daily
WHERE family = 'campaign';

CREATE VIEW state_summary AS
SELECT 'routes' AS entity, count(*) AS tracked_elements, count(*) FILTER (WHERE active) AS active_elements
FROM route_state
UNION ALL
SELECT 'favorites', count(*), count(*) FILTER (WHERE active)
FROM favorite_state;

CREATE VIEW recommendation_summary AS
SELECT count(*) FILTER (WHERE event_type = 'recommendation_seen') AS lists,
       coalesce(sum(len(place_ids)) FILTER (WHERE event_type = 'recommendation_seen'), 0) AS items_shown,
       count(*) FILTER (WHERE event_type = 'recommendation_added') AS saved_actions
FROM events;

CREATE VIEW policy_summary AS
SELECT simulation_run_id, cut_id, "case", status, reason, count(*) AS destinations,
       count(*) FILTER (WHERE automatic_increase) AS automatic_increases
FROM decisions
GROUP BY simulation_run_id, cut_id, "case", status, reason;

CREATE VIEW quality_summary AS
SELECT count(*) AS events,
       count(DISTINCT event_id) AS unique_events,
       count(DISTINCT simulation_run_id) AS runs_in_ledger,
       count(*) FILTER (WHERE NOT synthetic OR schema_version <> 1 OR source <> 'simulator') AS invalid_provenance
FROM events;

CREATE VIEW ctr_reconciliation AS
WITH cells AS (
    SELECT family, campaign_id, sum(eligible_impressions) AS eligible_impressions,
           sum(clicked_impressions) AS clicked_impressions, sum(eligible_click_actions) AS eligible_click_actions,
           sum(click_actions) AS click_actions
    FROM ctr_cells GROUP BY family, campaign_id
)
SELECT m.family, m.campaign_id,
       m.eligible_impressions = coalesce(c.eligible_impressions, 0)
       AND m.clicked_impressions = coalesce(c.clicked_impressions, 0)
       AND m.eligible_click_actions = coalesce(c.eligible_click_actions, 0)
       AND m.click_actions = coalesce(c.click_actions, 0)
       AND m.clicked_impressions <= m.eligible_impressions
       AND m.clicked_impressions <= m.eligible_click_actions
       AND m.eligible_click_actions <= m.click_actions AS reconciles
FROM campaign_metrics m LEFT JOIN cells c USING (family, campaign_id);
