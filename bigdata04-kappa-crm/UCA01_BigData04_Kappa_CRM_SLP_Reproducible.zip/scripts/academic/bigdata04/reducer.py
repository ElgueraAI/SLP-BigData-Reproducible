"""Canonical event reducer shared by live cuts, export and replay."""

import hashlib
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone

from contracts import BASE_FIELDS, EVENT_FIELDS
from policy import project_controls, stamp, utc


REDUCER_VERSION = "crm-v1"
LABEL = "ENTORNO ACADÉMICO — DATOS SINTÉTICOS"
ROUTE_MUTATIONS = {"destination_added", "destination_removed"}
FAVORITE_MUTATIONS = {"favorite_added", "favorite_removed"}
STATE_MUTATIONS = ROUTE_MUTATIONS | FAVORITE_MUTATIONS
IMPRESSION_TYPES = {"campaign_impression": "campaign", "destination_impression": "destination"}
CLICK_TYPES = {"campaign_click": "campaign", "destination_click": "destination"}


def canonical_json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def logical_hash(value):
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def business_event(raw):
    required, optional = EVENT_FIELDS[raw["event_type"]]
    fields = BASE_FIELDS | required | optional | {"campaign_id"}
    event = {name: raw[name] for name in fields if name in raw}
    event["event_time"] = stamp(event["event_time"])
    if "visible_fraction" in event:
        event["visible_fraction"] = float(event["visible_fraction"]) + 0.0
    return event


def canonical_events(records, run_id):
    events, conflicts = {}, set()
    for record in records:
        if record["simulation_run_id"] != run_id:
            raise ValueError("El corte contiene eventos de otra corrida")
        event = business_event(record)
        key = event["event_id"]
        if key in events and events[key] != event:
            conflicts.add(key)
        events.setdefault(key, event)
    return [events[key] for key in sorted(events.keys() - conflicts)], len(conflicts)


def ctr_row(keys, group, numbers):
    impressions, clicked, clicks, click_actions = numbers
    return {**dict(zip(keys, group)), "eligible_impressions": impressions, "clicked_impressions": clicked,
            "eligible_click_actions": clicks, "click_actions": click_actions,
            "ctr_pct": 100 * clicked / impressions if impressions else None}


def impression_key(event, family):
    return tuple(event.get(field) for field in ("demo_actor_id", "session_id", "destination_id", "campaign_id")) + (family,)


def click_group(event, family, day):
    return (family, day, event.get("campaign_id") or "", event["profile_id"], event.get("destination_id") or "")


def aggregate_ctr(events):
    exposures, clicks = defaultdict(list), []
    for event in events:
        event_type = event["event_type"]
        if event_type in IMPRESSION_TYPES:
            exposures[event["impression_id"]].append(event)
        elif event_type in CLICK_TYPES:
            clicks.append(event)
    cells = defaultdict(lambda: [0, 0, 0, 0])
    eligible, conflicts = {}, set()
    quality = Counter()
    for exposure_id, origins in exposures.items():
        if len(origins) != 1:
            # Cada id de exposición representa una impresión canónica única, inclusive entre familias.
            conflicts.add(exposure_id)
            quality["ambiguous_impression_ids"] += 1
            continue
        event = origins[0]
        family = IMPRESSION_TYPES[event["event_type"]]
        group = click_group(event, family, event["event_time"][:10])
        _ = cells[group]
        if event["visible_fraction"] >= 0.50 and event["visible_ms"] >= 1_000:
            eligible[exposure_id] = (event, family, group)
            cells[group][0] += 1
        else:
            quality["below_visibility_threshold"] += 1
    clicked_ids = set()
    for event in clicks:
        exposure_id = event["impression_id"]
        family = CLICK_TYPES[event["event_type"]]
        origin = eligible.get(exposure_id)
        click_day = event["event_time"][:10]
        group = click_group(event, family, click_day)
        if exposure_id in conflicts:
            quality["click_ambiguous_impression"] += 1
        elif exposure_id not in exposures:
            quality["click_missing_impression"] += 1
        elif origin is None:
            quality["click_below_visibility_threshold"] += 1
        elif impression_key(event, family) != impression_key(origin[0], origin[1]):
            quality["click_mismatched_impression"] += 1
        elif event["event_time"] < origin[0]["event_time"]:
            quality["click_before_impression"] += 1
        else:
            group = origin[2]
            cells[group][2] += 1
            if exposure_id not in clicked_ids:
                cells[group][1] += 1
                clicked_ids.add(exposure_id)
        cells[group][3] += 1
    keys = ("family", "day_utc", "campaign_id", "profile_id", "destination_id")
    return [ctr_row(keys, key, value) for key, value in sorted(cells.items())], dict(quality)


def rollup_ctr(rows, keys, expected=()):
    grouped = {key: [0, 0, 0, 0] for key in expected}
    for row in rows:
        key = tuple(row[field] for field in keys)
        totals = grouped.setdefault(key, [0, 0, 0, 0])
        for index, metric in enumerate(("eligible_impressions", "clicked_impressions", "eligible_click_actions", "click_actions")):
            totals[index] += row[metric]
    return [ctr_row(keys, key, totals) for key, totals in sorted(grouped.items())]


def state_rows(events):
    route_state, favorite_state, actions = {}, {}, []
    totals = {"routes": {"adds": 0, "removes": 0, "active": 0},
              "favorites": {"adds": 0, "removes": 0, "active": 0}}
    for event in events:
        kind = event["event_type"]
        if kind not in STATE_MUTATIONS:
            continue
        is_route = kind in ROUTE_MUTATIONS
        store = route_state if is_route else favorite_state
        active = kind.endswith("_added")
        category = "routes" if is_route else "favorites"
        state_key = (event["demo_actor_id"], event.get("route_id") if is_route else None, event["destination_id"])
        order = (event["event_sequence"], event["event_id"])
        row = {"demo_actor_id": state_key[0], "destination_id": state_key[2], "active": active,
               "event_sequence": order[0], "event_id": order[1], "event_time": event["event_time"]}
        if is_route:
            row["route_id"] = state_key[1]
        prev = store.get(state_key)
        if prev is None or order > (prev["event_sequence"], prev["event_id"]):
            store[state_key] = row
        totals[category]["adds" if active else "removes"] += 1
        actions.append({**row, "route_id": state_key[1], "event_type": kind})
    routes = [route_state[key] for key in sorted(route_state)]
    favorites = [favorite_state[key] for key in sorted(favorite_state)]
    totals["routes"]["active"] = sum(row["active"] for row in routes)
    totals["favorites"]["active"] = sum(row["active"] for row in favorites)
    return routes, favorites, sorted(actions, key=lambda item: (item["event_time"], item["event_id"])), totals


def interaction_summary(events, catalog):
    index = {dest["id"]: dest for dest in catalog["destinations"]}
    profiles, regions, destinations = (defaultdict(Counter) for _ in range(3))
    interests = {item: Counter() for item in catalog["interests"]}
    recommendations, event_types, clicks, quality = Counter(), Counter(), Counter(), Counter()
    sequences, sessions, routes = set(), {}, {}
    fields = {"destination_view": "views", "destination_added": "route_saves", "favorite_added": "favorite_saves",
              "route_generated": "routes_generated"}
    for event in events:
        kind = event["event_type"]
        actor, session, profile = (event[key] for key in ("demo_actor_id", "session_id", "profile_id"))
        sequence_key = (actor, event["event_sequence"])
        if sequence_key in sequences:
            quality["sequence_ties"] += 1
        sequences.add(sequence_key)
        if sessions.setdefault(session, actor) != actor:
            quality["session_owner_conflicts"] += 1
        route = event.get("route_id")
        if route and routes.setdefault(route, actor) != actor:
            quality["route_owner_conflicts"] += 1
        destination = event.get("destination_id")
        event_types[kind] += 1
        profiles[profile]["events"] += 1
        if destination is not None:
            region = index[destination]["region"]
            destinations[destination]["events"] += 1
            regions[region]["events"] += 1
            if kind in CLICK_TYPES:
                clicks[destination] += 1
        if kind == "category_selected":
            interests[event["interest"]]["selected" if event["selected"] else "deselected"] += 1
        elif kind == "recommendation_seen":
            recommendations["lists"] += 1
            recommendations["items_shown"] += len(event["place_ids"])
        elif kind == "recommendation_added":
            recommendations["saved_actions"] += 1
        if kind in fields:
            metric = fields[kind]
            profiles[profile][metric] += 1
            if destination is not None:
                destinations[destination][metric] += 1
                regions[region][metric] += 1
    fields = ("events", "views", "route_saves", "favorite_saves", "routes_generated")
    def rows(source, ids, key):
        return [{key: item, **{name: source[item][name] for name in fields}} for item in sorted(ids)]
    return {
        "event_types": dict(sorted(event_types.items())),
        "recommendations": {key: recommendations[key] for key in ("lists", "items_shown", "saved_actions")},
        "profiles": rows(profiles, catalog["profiles"], "profile_id"),
        "regions": rows(regions, {dest["region"] for dest in index.values()}, "region"),
        "destinations": [{**row, **{name: index[row["destination_id"]][name] for name in ("id", "name", "region", "interests")}}
                         for row in rows(destinations, index, "destination_id")],
        "interests": [{"interest": item, "selected": counts["selected"], "deselected": counts["deselected"]}
                      for item, counts in sorted(interests.items())],
    }, clicks, dict(quality)


def reduce_events(events, catalog, controls=(), as_of=None, run_id=None):
    as_of = utc(as_of or datetime.now(timezone.utc))
    events = list(events)
    controls = list(controls)
    if not run_id:
        if events:
            run_id = events[0]["simulation_run_id"]
        elif controls:
            run_id = controls[0]["simulation_run_id"]
        else:
            raise ValueError("El corte vacío requiere identificador de corrida")
    events, conflict_count = canonical_events(events, run_id)
    if any(revision["simulation_run_id"] != run_id for revision in controls):
        raise ValueError("El corte contiene controles de otra corrida")
    controls = sorted(({key: value for key, value in revision.items() if key != "_id"} for revision in controls),
                      key=lambda row: (row["destination_id"], row["revision"]))
    cells, attr_quality = aggregate_ctr(events)
    campaign_metrics = rollup_ctr(cells, ("family", "campaign_id"),
                                  [("campaign", name) for name in catalog["campaigns"]] + [("destination", "")])
    ctr_daily = rollup_ctr(cells, ("family", "day_utc", "campaign_id"))
    routes, favorites, actions, state_totals = state_rows(events)
    metrics, clicks, quality = interaction_summary(events, catalog)
    decisions, decision_history = project_controls(controls, catalog["destinations"], clicks, as_of)
    tables = {"events": events, "campaign_metrics": campaign_metrics, "ctr_daily": ctr_daily, "ctr_cells": cells,
              "route_state": routes, "favorite_state": favorites, "state_actions": actions, "controls": controls,
              "decisions": decisions, "decision_history": decision_history,
              **{key: metrics[key] for key in ("profiles", "regions", "destinations", "interests")}}
    summary = {**metrics, "campaign_metrics": campaign_metrics, "ctr_daily": ctr_daily, "state_totals": state_totals,
               "quality": {"canonical_id_conflicts": conflict_count, **quality, **attr_quality}}
    # La fecha de evaluación se fija para estudios de replay. El hash identifica el resultado reproducido.
    corpus_hash = logical_hash(events)
    hashes = {"corpus": corpus_hash, "controls": logical_hash(controls),
              "results": logical_hash({"tables": {key: rows for key, rows in tables.items() if key != "events"},
                                       "summary": summary})}
    return {"reducer_version": REDUCER_VERSION, "simulation_run_id": run_id, "as_of": stamp(as_of),
            "hashes": hashes, "tables": tables, "metrics": summary}
