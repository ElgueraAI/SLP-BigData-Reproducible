"""Escenario breve A–D para observar un mismo itinerario antes y después de la revisión."""
import argparse
import datetime as dt
import json
import uuid
import urllib.request
from benchmark import Stack
from contracts import is_run_id


def demonstration(run):
    all_events = []
    def emit(kind, **fields):
        sequence = len(all_events)+1
        stamp = dt.datetime(2026,11,25,15,tzinfo=dt.timezone.utc)+dt.timedelta(seconds=sequence)
        row = dict(source="simulator",synthetic=True,schema_version=1,simulation_run_id=run,
                   event_id=str(uuid.uuid5(uuid.NAMESPACE_URL,f"demo/{run}/{sequence}")),event_type=kind,
                   event_time=stamp.isoformat(),event_sequence=sequence,demo_actor_id="actor-1",
                   session_id="session-1-1",profile_id="viajero-cultural",**fields)
        all_events.append(row)
    for i,dest in enumerate(["H07"]*8+["H06"],1):
        link = dict(destination_id=dest,impression_id=f"imp-1-{i}",campaign_id="camp-cultura")
        emit("campaign_impression",visible_fraction=1.0,visible_ms=1300,**link)
        if i<=7:
            emit("campaign_click",**link)
    emit("destination_added",destination_id="H07",route_id="route-1-1")
    emit("destination_added",destination_id="H06",route_id="route-1-1")
    emit("favorite_added",destination_id="H07")
    boundary = len(all_events)
    emit("destination_removed",destination_id="H07",route_id="route-1-1")
    emit("favorite_removed",destination_id="H07")
    emit("favorite_added",destination_id="H07")
    return all_events[:boundary], [all_events[0], *all_events[boundary:]]


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run",required=True)
    parser.add_argument("--stage",choices=["initial","change"],required=True)
    parser.add_argument("--offline",action="store_true")
    args=parser.parse_args()
    if not is_run_id(args.run):
        parser.error("Identificador de corrida no válido")
    stack=Stack(args.offline)
    stack.python("policy.py","--run-id",args.run,"--stage",args.stage)
    body=demonstration(args.run)[args.stage=="change"]
    req=urllib.request.Request("http://127.0.0.1:18404/events", data=json.dumps(body).encode(),
                               headers={"Content-Type":"application/json"})
    with urllib.request.urlopen(req,timeout=30) as response:
        result=json.load(response)
    assert result["accepted"]==len(body)
    print(json.dumps({"attempts":len(body),"first_ack":result["results"][0],"positions":stack.drain()},indent=2))
