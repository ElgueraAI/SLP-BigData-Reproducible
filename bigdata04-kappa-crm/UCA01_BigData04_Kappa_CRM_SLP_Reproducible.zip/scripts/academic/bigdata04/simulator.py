"""Funnel de sesiones ficticias reproducibles. Publica únicamente a la API local."""
import argparse
import collections
import dataclasses
import datetime as dt
import http.client
import json
import math
import random
import time
import uuid
from pathlib import Path
from urllib.parse import urlsplit

CATALOG = json.loads(Path(__file__).with_name("catalog.json").read_text(encoding="utf-8"))
PREFERENCE = dict(zip(CATALOG["profiles"], ("naturaleza", "aventura", "cultura", "historia",
                                           "gastronomia", "pueblos-magicos", "familia", "relajacion")))
ORIGIN = dt.datetime(2026, 11, 25, 12, tzinfo=dt.timezone.utc)


@dataclasses.dataclass
class Actor:
    number: int
    profile: str
    sequence: int = 0
    session: int = 0
    route: set = dataclasses.field(default_factory=set)
    favorites: set = dataclasses.field(default_factory=set)


def attempts(args, stats):
    """Inject faults only after creating causal actions. Transport reordering preserves event time."""
    rng = random.Random(args.seed)
    places = [p for p in CATALOG["destinations"] if not args.region or p["region"] == args.region]
    actors, pending, held = [], collections.deque(), collections.deque()
    previous = None
    logical_clock = 0
    for index in range(args.count):
        if previous and rng.random() < args.duplicates / 100:
            stats["duplicates_generated"] += 1
            yield dict(previous)
            continue
        if rng.random() < args.invalid / 100:
            stats["invalid_generated"] += 1
            yield {"schema_version": 999, "source": "simulator", "synthetic": True,
                   "simulation_run_id": args.run}
            continue
        if held and (held[0][0] <= index or index >= args.count - len(held)):
            _, previous = held.popleft()
            yield previous
            continue
        if not pending:
            if actors and rng.random() < args.repeat / 100:
                actor = rng.choice(actors)
            else:
                actor = Actor(len(actors) + 1, args.profile or rng.choice(CATALOG["profiles"]))
                actors.append(actor)
            actor.session += 1
            interest = PREFERENCE[actor.profile]
            place = rng.choices(places, weights=[1 + 2 * (interest in p["interests"]) for p in places])[0]
            dest = place["id"]
            campaign = args.campaign or rng.choice(CATALOG["campaigns"])
            route = f"route-{actor.number}-1"

            def add(kind, **fields):
                nonlocal logical_clock
                actor.sequence += 1
                logical_clock += 1
                ident = uuid.uuid5(uuid.NAMESPACE_URL, f"slp/v1/{args.run}/{actor.number}/{actor.sequence}")
                pending.append(dict(schema_version=1, event_id=str(ident), event_type=kind,
                                    event_time=(ORIGIN + dt.timedelta(seconds=logical_clock)).isoformat().replace("+00:00","Z"),
                                    source="simulator", synthetic=True, simulation_run_id=args.run,
                                    demo_actor_id=f"actor-{actor.number}", session_id=f"session-{actor.number}-{actor.session}",
                                    profile_id=actor.profile, event_sequence=actor.sequence, **fields))

            add("category_selected", interest=interest, selected=True)
            for family in ("campaign", "destination"):
                exposure = dict(destination_id=dest, campaign_id=campaign,
                                impression_id=f"imp-{actor.number}-{actor.sequence + 1}")
                add(f"{family}_impression", **exposure, visible_fraction=rng.choice([0.4, 0.65, 0.9, 1.0]),
                    visible_ms=rng.choice([750, 1000, 1600, 2200]))
                if rng.random() < 0.40:
                    add(f"{family}_click", **exposure)
            add("destination_view", destination_id=dest)
            choices = list(dict.fromkeys([dest, rng.choice(places)["id"]]))
            add("recommendation_seen", place_ids=choices, surface="discover")
            if dest not in actor.route and rng.random() < 0.55:
                add("recommendation_added", destination_id=dest, route_id=route)
                add("destination_added", destination_id=dest, route_id=route)
                actor.route.add(dest)
            if dest not in actor.favorites and rng.random() < 0.38:
                add("favorite_added", destination_id=dest)
                actor.favorites.add(dest)
            if actor.route and rng.random() < 0.7:
                add("route_generated", route_id=route, stops=len(actor.route))
            for active, kind in [(actor.route, "destination_removed"), (actor.favorites, "favorite_removed")]:
                if active and rng.random() < args.removals / 100:
                    removed = rng.choice(sorted(active))
                    add(kind, destination_id=removed, **({"route_id": route} if active is actor.route else {}))
                    active.remove(removed)
        event = pending.popleft()
        if index + 32 < args.count and rng.random() < args.late / 100:
            held.append((index + 32, event))
            stats["departures_delayed"] += 1
            if pending:
                event = pending.popleft()
            else:
                _, event = held.popleft()
        previous = event
        yield event


def arguments(parser):
    parser.add_argument("--run", required=True)
    parser.add_argument("--count", type=int, default=1000)
    parser.add_argument("--rate", type=float, default=0, help="Intentos/s, cero libera el límite.")
    parser.add_argument("--duration", type=float, help="Con tasa, acota los intentos a tasa × segundos.")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--region", choices=sorted({p["region"] for p in CATALOG["destinations"]}))
    parser.add_argument("--profile", choices=CATALOG["profiles"])
    parser.add_argument("--campaign", choices=CATALOG["campaigns"])
    for name, default in [("duplicates", 3), ("late", 5), ("invalid", 2), ("repeat", 55), ("removals", 30)]:
        parser.add_argument("--" + name, type=float, default=default, help="Porcentaje [0,100]")
    parser.add_argument("--batch", type=int, default=250)
    parser.add_argument("--restart-every", type=int, default=0, help="Reconectar productor HTTP cada N lotes.")
    parser.add_argument("--url", default="http://127.0.0.1:18404")


def publish(args, progress=None):
    url = urlsplit(args.url)
    if url.hostname not in {"localhost", "127.0.0.1", "api"} or url.scheme != "http":
        raise ValueError("La demo admite únicamente la API local.")
    if args.duration is not None:
        if args.rate <= 0 or args.duration <= 0:
            raise ValueError("La duración necesita una tasa y duración positivas.")
        args.count = min(args.count, math.floor(args.rate * args.duration))
    if not 1 <= args.count <= 1_000_000 or not 1 <= args.batch <= 1000 or args.rate < 0 or args.restart_every < 0:
        raise ValueError("Volumen, tamaño de lote, pausa o cadencia fuera de rango.")
    if any(not 0 <= getattr(args, name) <= 100 for name in ("duplicates","late","invalid","repeat","removals")):
        raise ValueError("Porcentaje fuera de rango.")
    stats = collections.Counter()
    stream = iter(attempts(args, stats))
    start = time.perf_counter()
    conn = http.client.HTTPConnection(url.hostname, url.port, timeout=40)
    positions = {}
    try:
        while stats["attempts"] < args.count:
            tick = time.perf_counter()
            batch = [next(stream) for _ in range(min(args.batch, args.count - stats["attempts"]))]
            stats["generation_s"] += time.perf_counter() - tick
            tick = time.perf_counter()
            conn.request("POST", "/events", json.dumps(batch, separators=(",", ":")), {"Content-Type":"application/json"})
            response = conn.getresponse()
            raw = response.read()
            if response.status not in (202, 207, 400, 422):
                raise RuntimeError(f"API HTTP {response.status}, lote sin reconciliar")
            reply = json.loads(raw)
            if len(reply["results"]) != len(batch) or reply["retry"]:
                raise RuntimeError("Acuses parciales o inciertos, se requiere reconciliación.")
            stats["publish_s"] += time.perf_counter() - tick
            for item in reply["results"]:
                if item.get("offset") is not None:
                    key = f"{item['topic']}/{item['partition']}"
                    positions[key] = max(positions.get(key, 0), item["offset"] + 1)
            stats.update(attempts=len(batch), accepted=reply["accepted"], rejected=reply["rejected"], batches=1)
            if progress:
                progress(stats)
            if args.restart_every and stats["batches"] % args.restart_every == 0:
                conn.close()
                stats["producer_reconnections"] += 1
            if args.rate:
                time.sleep(max(0, stats["attempts"] / args.rate - (time.perf_counter() - start)))
    finally:
        conn.close()
    return {**stats, "run": args.run, "seed": args.seed, "elapsed_s": time.perf_counter()-start, "positions": positions}


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    arguments(cli)
    print(json.dumps(publish(cli.parse_args()), indent=2))
