"""MongoDB primitives accessed through one local mongosh process per Store instance."""

import hashlib
import json
import os
import re
import subprocess
import threading
from pathlib import Path
from queue import Empty, Queue

from contracts import MAX_SEQUENCE, Validator, is_run_id, json_bytes, load_catalog, parse_utc, utc_text


RESPONSE_MARKER = b"CRM_JSON "
DATABASE = re.compile(r"slp_bigdata04_[a-z][a-z0-9_]{0,40}", re.ASCII)
TOKEN = re.compile(r"[a-zA-Z0-9_-]{1,64}", re.ASCII)
SEMANTIC_ERROR = re.compile(r"(?:control_conflict|invalid_operation|mongo_(?:operation_failed|[0-9]+))")
DEFAULT_URI = "mongodb://mongo:27017/?connectTimeoutMS=2000&serverSelectionTimeoutMS=3000&socketTimeoutMS=45000"


class StoreError(RuntimeError):
    pass


class Store:
    def __init__(self, mongo_uri=None, database=None, timeout=None):
        self.uri = mongo_uri or os.getenv("MONGO_URI", DEFAULT_URI)
        self.database = database or os.getenv("MONGO_DATABASE", "slp_bigdata04_demo")
        if not DATABASE.fullmatch(self.database):
            raise ValueError("invalid_demo_database")
        self.timeout = float(os.getenv("MONGO_BRIDGE_TIMEOUT", "60")) if timeout is None else timeout
        self._process = None
        self._responses = None
        self._lock = threading.Lock()

    def __enter__(self):
        return self

    def __exit__(self, *_exc):
        self.close()

    def _start(self):
        name = json.dumps(self.database)
        script = Path(__file__).with_name("mongo.js").read_text(encoding="utf-8")
        process = subprocess.Popen(
            [os.getenv("MONGO_SHELL", "mongosh"), "--quiet", "--norc", self.uri,
             "--eval", f"const databaseName = {name};\n{script}"],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
        )
        responses = Queue()

        def receive():
            for line in process.stdout:
                if line.startswith(RESPONSE_MARKER):
                    responses.put(line.removeprefix(RESPONSE_MARKER))
            responses.put(None)

        threading.Thread(target=receive, daemon=True, name="mongo-shell-reader").start()
        self._process = process
        self._responses = responses

    def _close(self):
        process = self._process
        self._process = None
        self._responses = None
        if process is None:
            return
        try:
            process.stdin.close()
        except OSError:
            pass
        try:
            process.wait(timeout=0.5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=2)
        finally:
            process.stdout.close()

    def close(self):
        with self._lock:
            self._close()

    def _call(self, operation, **values):
        payload = json_bytes({"op": operation, **values}) + b"\n"
        with self._lock:
            try:
                if self._process is None:
                    self._start()
                self._process.stdin.write(payload)
                self._process.stdin.flush()
                line = self._responses.get(timeout=self.timeout)
                if line is None:
                    raise EOFError
                response = json.loads(line)
                if type(response) is not dict or type(response.get("ok")) is not bool:
                    raise ValueError
            except (Empty, EOFError, OSError, ValueError):
                self._close()
                raise StoreError("mongo_bridge_unavailable") from None
            if not response["ok"]:
                reason = response.get("error")
                if type(reason) is not str or not SEMANTIC_ERROR.fullmatch(reason):
                    reason = "mongo_operation_failed"
                raise StoreError(reason)
            return response["value"]

    @staticmethod
    def _run(run_id):
        if not is_run_id(run_id):
            raise ValueError("invalid_run_id")
        return run_id

    @staticmethod
    def _positions(positions):
        if positions is None:
            return None
        if not isinstance(positions, dict) or len(positions) > 100:
            raise ValueError("invalid_positions")
        result = {}
        for partition, offset in positions.items():
            key = str(partition)
            if not re.fullmatch(r"0|[1-9][0-9]?", key, re.ASCII) or type(offset) is not int or not 0 <= offset <= MAX_SEQUENCE:
                raise ValueError("invalid_positions")
            result[key] = offset
        return result

    def ping(self):
        return self._call("ping")

    def initialize(self):
        return self._call("initialize")

    def persist_batch(self, rows, api_rejections, late_tolerance_ms):
        return self._call(
            "persistBatch", rows=rows, api_rejections=api_rejections, late_tolerance_ms=late_tolerance_ms,
        )

    def complete_batch(self, positions, quarantine_positions, acknowledged_quarantine_ids, telemetry):
        return self._call(
            "completeBatch", positions=positions, quarantine_positions=self._positions(quarantine_positions),
            acknowledged_quarantine_ids=acknowledged_quarantine_ids, telemetry=telemetry,
        )

    def heartbeat(self, status, committed_positions=None, log_end_offsets=None, late_tolerance_ms=None):
        if status not in {"starting", "running", "degraded", "stopped", "retention_gap"}:
            raise ValueError("invalid_status")
        return self._call(
            "heartbeat", status=status, committed_positions=self._positions(committed_positions),
            log_end_offsets=self._positions(log_end_offsets), late_tolerance_ms=late_tolerance_ms,
        )

    def trigger_once(self, marker):
        if type(marker) is not str or not TOKEN.fullmatch(marker):
            raise ValueError("invalid_fault_marker")
        return self._call("triggerOnce", marker=marker)

    def read_events(self, run_id, position_cut=None):
        return self._call("readEvents", run=self._run(run_id), positions=self._positions(position_cut))

    def read_deliveries(self, run_id, position_cut=None):
        return self._call("readDeliveries", run=self._run(run_id), positions=self._positions(position_cut))

    def read_controls(self, run_id):
        return self._call("readControls", run=self._run(run_id))

    def put_control(self, control):
        validator = Validator(load_catalog(os.getenv("CRM_CATALOG")))
        value = validator.control(control)
        fingerprint = hashlib.sha256(json_bytes(value)).hexdigest()
        return self._call("putControl", control=value, fingerprint=fingerprint)

    def read_audit(self, run_id):
        return self._call("readAudit", run=self._run(run_id))

    def read_progress(self, run_id):
        return self._call("readProgress", run=self._run(run_id))

    def read_snapshot(self, run_id, include_deliveries=True):
        if type(include_deliveries) is not bool:
            raise ValueError("invalid_include_deliveries")
        return self._call("readSnapshot", run=self._run(run_id), include_deliveries=include_deliveries)

    def list_runs(self):
        return self._call("listRuns")

    def publish_cut(self, run_id, cut):
        run = self._run(run_id)
        if type(cut) is not dict or "_id" in cut or cut.get("simulation_run_id") != run:
            raise ValueError("invalid_projection_cut")
        cut_id = cut.get("cut_id")
        if type(cut_id) is not str or not re.fullmatch(r"[a-zA-Z0-9_-]{1,128}", cut_id, re.ASCII):
            raise ValueError("invalid_projection_cut")
        normalized = {**cut, "as_of": utc_text(parse_utc(cut.get("as_of"), "as_of"))}
        if len(json_bytes(normalized)) > 4 * 1024 * 1024:
            raise ValueError("projection_cut_too_large")
        return self._call("publishCut", run=run, cut=normalized)

    def read_cut(self, run_id):
        return self._call("readCut", run=self._run(run_id))
