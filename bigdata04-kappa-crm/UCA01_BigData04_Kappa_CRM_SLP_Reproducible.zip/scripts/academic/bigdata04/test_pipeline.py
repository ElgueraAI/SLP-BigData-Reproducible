"""Contract/HTTP oracles and optional tests against the real local MongoDB."""

import json
import os
import unittest
from uuid import NAMESPACE_DNS, uuid4, uuid5

from tornado.testing import AsyncHTTPTestCase

from api import make_application
from consumer import api_quarantine_message, validate_broker_message
from contracts import (
    EVENT_FIELDS, EVENT_TOPIC, QUARANTINE_TOPIC, ContractError, Validator, decode_json,
    fingerprint, json_bytes, partition_key, rejection, utc_text,
)
from store import Store, StoreError


CATALOG = {
    "destinations": [
        {"id": "H06", "name": "Aquismón", "region": "huasteca", "interests": ["agua"]},
        {"id": "H07", "name": "Xilitla", "region": "huasteca", "interests": ["cultura"]},
    ],
    "profiles": ["explorador-natural"],
    "interests": ["agua", "cultura"],
    "campaigns": ["camp-agua", "camp-cultura"],
}
TYPES = {
    "destination_view": {"destination_id": "H06"},
    "category_selected": {"interest": "agua", "selected": True},
    "recommendation_seen": {"place_ids": ["H07", "H06"], "surface": "discover"},
    "recommendation_added": {"destination_id": "H06", "route_id": "route-4-1"},
    "destination_added": {"destination_id": "H06", "route_id": "route-4-1"},
    "destination_removed": {"destination_id": "H06", "route_id": "route-4-1"},
    "route_generated": {"route_id": "route-4-1", "stops": 3},
    "favorite_added": {"destination_id": "H06"},
    "favorite_removed": {"destination_id": "H06"},
    "destination_impression": {"destination_id": "H06", "impression_id": "imp-4-2", "visible_fraction": 0.5, "visible_ms": 1000},
    "destination_click": {"destination_id": "H06", "impression_id": "imp-4-2"},
    "campaign_impression": {"campaign_id": "camp-agua", "impression_id": "imp-4-3", "visible_fraction": 0.48, "visible_ms": 975},
    "campaign_click": {"campaign_id": "camp-agua", "impression_id": "imp-4-3"},
}


def event(event_type="destination_view", sequence=1, **overrides):
    return {
        "schema_version": 1, "source": "simulator", "synthetic": True,
        "event_id": str(uuid5(NAMESPACE_DNS, f"crm-lab/{event_type}/{sequence}")), "event_type": event_type,
        "event_time": "2026-11-25T12:00:00Z", "event_sequence": sequence, "simulation_run_id": "run-pipeline",
        "demo_actor_id": "actor-4", "session_id": "session-4-1", "profile_id": "explorador-natural",
        **TYPES[event_type], **overrides,
    }


class TestContract(unittest.TestCase):
    def setUp(self):
        self.validator = Validator(CATALOG)

    def test_all_types_and_required_fields(self):
        self.assertEqual(set(TYPES), set(EVENT_FIELDS))
        for name, (required, _) in EVENT_FIELDS.items():
            payload = event(name)
            with self.subTest(name=name):
                valid = self.validator.event(payload)
                self.assertEqual(valid["event_type"], name)
                self.assertNotIn("received_at", valid)
            for field in required:
                with self.subTest(name=name, field=field):
                    with self.assertRaisesRegex(ContractError, "^missing_fields$"):
                        self.validator.event({key: value for key, value in payload.items() if key != field})

    def test_strict_shape_types_and_catalogs(self):
        changes = [
            ({"schema_version": True}, "schema_version"), ({"schema_version": 2}, "schema_version"),
            ({"source": "web"}, "source"), ({"synthetic": 1}, "synthetic"),
            ({"event_id": "arbitrary"}, "event_id"), ({"event_time": "2026-11-25T12:00:00"}, "event_time"),
            ({"event_time": "2026-11-31T12:00:00Z"}, "event_time"),
            ({"event_time": "2026-11-25T12:00:00-06:00"}, "event_time"),
            ({"event_sequence": 0}, "event_sequence"), ({"event_sequence": "2"}, "event_sequence"),
            ({"profile_id": "unknown"}, "profile_id"), ({"campaign_id": "unknown"}, "campaign_id"),
            ({"destination_id": "XX99"}, "destination_id"), ({"session_id": "session-99-1"}, "scoped_id"),
            ({"simulation_run_id": "run-test/path"}, "run_id"),
            ({"coordinates": [22.15, -100.98]}, "unknown_fields"),
            ({"private_note": "privacy-canary"}, "unknown_fields"),
            ({"received_at": "2026-11-25T12:00:00Z"}, "unknown_fields"),
        ]
        for payload, reason in changes:
            with self.subTest(payload=payload):
                with self.assertRaisesRegex(ContractError, f"^{reason}$"):
                    self.validator.event(event(**payload))
        with self.assertRaisesRegex(ContractError, "^selected$"):
            self.validator.event(event("category_selected", selected=1))
        with self.assertRaisesRegex(ContractError, "^place_ids$"):
            self.validator.event(event("recommendation_seen", place_ids=["H06", "H06"]))

    def test_serialization_and_fingerprint(self):
        with self.assertRaisesRegex(ContractError, "^invalid_json$"):
            decode_json(b'{"a":1,"a":2}')
        with self.assertRaisesRegex(ContractError, "^invalid_json$"):
            decode_json(b'{"a":NaN}')
        first = self.validator.event(event("campaign_impression", visible_fraction=1))
        second = self.validator.event(event(
            "campaign_impression", event_time="2026-11-25T12:00:00.000000+00:00", visible_fraction=1.0,
        ))
        self.assertEqual(fingerprint(first), fingerprint({**second, "received_at": utc_text(), "offset": 99}))
        self.assertNotEqual(fingerprint(first), fingerprint({**second, "campaign_id": "camp-cultura"}))


class FakeMsg:
    def __init__(self, topic, value, key, partition=0, offset=0):
        self._topic = topic
        self._value = value
        self._key = key
        self._partition = partition
        self._offset = offset

    def topic(self):
        return self._topic

    def value(self):
        return self._value

    def key(self):
        return self._key

    def partition(self):
        return self._partition

    def offset(self):
        return self._offset


class TestBrokerContract(unittest.TestCase):
    def test_read_valid_and_sanitize_bypass(self):
        validator = Validator(CATALOG)
        good = event(received_at=utc_text())
        accepted = validate_broker_message(FakeMsg(EVENT_TOPIC, json_bytes(good), partition_key(good)), validator)
        self.assertEqual(accepted["event"]["event_id"], good["event_id"])
        self.assertEqual(accepted["fingerprint"], fingerprint(good))
        wrong_key = validate_broker_message(FakeMsg(EVENT_TOPIC, json_bytes(good), b"wrong"), validator)
        self.assertEqual(wrong_key["quarantine"]["reason"], "invalid_key")
        private = {**good, "private_note": "privacy-canary"}
        banned = validate_broker_message(FakeMsg(EVENT_TOPIC, json_bytes(private), partition_key(good)), validator)
        self.assertEqual(banned["quarantine"]["reason"], "unknown_fields")
        self.assertNotIn("privacy-canary", json.dumps(banned))
        self.assertNotIn(good["event_id"], json.dumps(banned))

    def test_quarantine_topic_separates_origins(self):
        valid = rejection("unknown_fields", "api", event())
        accepted = api_quarantine_message(FakeMsg(QUARANTINE_TOPIC, json_bytes(valid), b"api", partition=2))
        self.assertEqual(accepted["partition"], 2)
        self.assertEqual(accepted["quarantine"]["simulation_run_id"], "run-pipeline")
        private = {**valid, "private_note": "privacy-canary"}
        self.assertIsNone(api_quarantine_message(FakeMsg(QUARANTINE_TOPIC, json_bytes(private), b"api")))
        self.assertIsNone(api_quarantine_message(FakeMsg(QUARANTINE_TOPIC, json_bytes(valid), b"not-api")))


class FakePublisher:
    def __init__(self):
        self.healthy = True
        self.records = []

    def health(self):
        return self.healthy

    async def publish(self, records):
        self.records.extend(records)
        return [
            ({"topic": topic, "partition": 2, "offset": index}, None) if self.healthy
            else (None, "broker_timeout")
            for index, (topic, _key, _value) in enumerate(records)
        ]


class TestAPI(AsyncHTTPTestCase):
    def get_app(self):
        self.publisher = FakePublisher()
        return make_application(self.publisher, Validator(CATALOG))

    def post(self, body):
        return self.fetch("/events", method="POST", headers={"Content-Type": "application/json"}, body=json_bytes(body))

    def test_acknowledged_valid_and_invalid_items(self):
        response = self.post([event(), event(private_note="privacy-canary"), event("campaign_click")])
        self.assertEqual(response.code, 207)
        output = json.loads(response.body)
        self.assertEqual((output["accepted"], output["rejected"], output["retry"]), (2, 1, 0))
        self.assertEqual(output["results"][0]["offset"], 0)
        self.assertEqual(output["results"][1], {"status": "rejected", "reason": "unknown_fields"})
        self.assertEqual([row[0] for row in self.publisher.records], [EVENT_TOPIC, QUARANTINE_TOPIC, EVENT_TOPIC])
        bodies = [record[2] for record in self.publisher.records]
        self.assertIn("received_at", bodies[0])
        self.assertNotIn("privacy-canary", json.dumps(bodies))
        self.assertNotIn(b"privacy-canary", response.body)

    def test_status_codes_and_failed_ack(self):
        self.assertEqual(self.post(event()).code, 202)
        self.assertEqual(self.post(event(schema_version=2)).code, 400)
        self.assertEqual(self.post([]).code, 413)
        self.assertEqual(self.fetch("/health").code, 200)
        self.publisher.healthy = False
        self.assertEqual(self.fetch("/health").code, 503)
        response = self.post([event(), event(schema_version=2)])
        self.assertEqual(response.code, 503)
        self.assertEqual(json.loads(response.body)["retry"], 2)


@unittest.skipUnless(os.getenv("CRM_TEST_MONGO_URI"), "requires real local MongoDB and mongosh")
class TestMongo(unittest.TestCase):
    def setUp(self):
        self.store = Store(mongo_uri=os.environ["CRM_TEST_MONGO_URI"], database=f"slp_bigdata04_test_{uuid4().hex[:10]}")
        self.addCleanup(self.store.close)
        self.assertTrue(self.store.initialize())
        self.validator = Validator(CATALOG)

    def row(self, payload, offset, partition=0):
        accepted = self.validator.event({**payload, "received_at": utc_text()}, broker=True)
        return {**{"topic": EVENT_TOPIC, "partition": partition, "offset": offset},
                "event": accepted, "fingerprint": fingerprint(accepted)}

    def finalize(self, persisted, quarantine_offsets=None):
        acknowledged = [record["delivery_id"] for record in persisted["pending_quarantine"]]
        return self.store.complete_batch(persisted["positions"], quarantine_offsets or {}, acknowledged, None)

    def test_batched_canonical_classification_cuts_and_replay(self):
        first = event()
        old = event(sequence=2, event_time="2026-11-25T11:59:40Z")
        conflict = {**first, "destination_id": "H07"}
        position = {"topic": EVENT_TOPIC, "partition": 0, "offset": 4}
        rejected = {**position, "quarantine": rejection("unknown_fields", "consumer", first, position)}
        rows = [self.row(first, 0), self.row(old, 1), self.row(first, 2), self.row(conflict, 3), rejected]
        pending = self.store.persist_batch(rows, [], 5000)
        self.assertEqual(len(pending["pending_quarantine"]), 2)
        self.assertEqual(self.store.read_events("run-pipeline"), [])
        self.assertEqual(self.store.read_events("run-pipeline", {0: 5}), [])
        replay = self.store.persist_batch(rows, [], 5000)
        self.assertEqual(replay["replays"], 5)
        self.assertTrue(self.finalize(replay))
        audit = self.store.read_audit("run-pipeline")
        self.assertEqual(audit["positions"], {"0": 5})
        self.assertEqual(audit["counts"], {
            "new": 2, "duplicate": 1, "conflict": 1, "rejected": 1, "late": 1, "late_new": 1, "deliveries": 5,
        })
        self.assertEqual(audit["latency_ms"]["n"], 2)
        snapshot = self.store.read_snapshot("run-pipeline")
        self.assertEqual(len(snapshot["events"]), 2)
        self.assertEqual(snapshot["events"][0]["destination_id"], "H06")
        compact = self.store.read_snapshot("run-pipeline", include_deliveries=False)
        self.assertEqual(compact["deliveries"], [])
        self.assertEqual(compact["audit"]["counts"], snapshot["audit"]["counts"])
        self.assertEqual(len(self.store.read_events("run-pipeline", {0: 1})), 1)
        self.assertEqual(self.store.read_events("run-other"), [])
        self.assertEqual(self.store.list_runs(), ["run-pipeline"])
        second_replay = self.store.persist_batch(rows, [], 5000)
        self.assertEqual(second_replay["pending_quarantine"], [])
        self.assertEqual(self.store.read_audit("run-pipeline")["counts"], audit["counts"])

    def test_partitioned_quarantine_and_immutable_revisions(self):
        invalid = rejection("event_type", "api", event())
        rows = [
            {"topic": QUARANTINE_TOPIC, "partition": partition, "offset": 0, "quarantine": invalid}
            for partition in (0, 2)
        ]
        pending = self.store.persist_batch([], rows, 5000)
        self.assertTrue(self.finalize(pending, {0: 1}))
        self.assertEqual(self.store.read_progress("run-pipeline")["quarantine_count"], 1)
        self.assertTrue(self.finalize(pending, {2: 1}))
        self.assertEqual(self.store.read_progress("run-pipeline")["quarantine_count"], 2)
        control = {
            "simulation_run_id": "run-pipeline", "destination_id": "H06", "revision": 1,
            "recorded_at": "2026-11-25T12:00:00Z", "valid_from": "2026-11-25T12:00:00Z",
            "valid_to": "2026-11-26T12:00:00Z", "capacity": 10, "reservations": 4, "available": True,
            "access": "open", "environmental_status": "clear", "source": "synthetic-operations-v1",
            "verified": True, "case": "B",
        }
        self.assertTrue(self.store.put_control(control))
        self.assertFalse(self.store.put_control(control))
        with self.assertRaisesRegex(StoreError, "^control_conflict$"):
            self.store.put_control({**control, "capacity": 12})
        self.assertEqual(self.store.read_controls("run-pipeline")[0]["capacity"], 10)

    def test_projection_cut_publishes_only_moving_forward(self):
        run = "run-pipeline"
        cut = {"simulation_run_id": run, "cut_id": "c1", "as_of": "2026-11-25T12:00:00Z", "metrics": {"count": 1}}
        self.assertIsNone(self.store.read_cut(run))
        self.assertTrue(self.store.publish_cut(run, cut))
        self.assertFalse(self.store.publish_cut(run, cut))
        self.assertFalse(self.store.publish_cut(run, {**cut, "cut_id": "old", "as_of": "2026-11-25T11:00:00Z"}))
        self.assertEqual(self.store.read_cut(run)["cut_id"], "c1")
        self.assertTrue(self.store.publish_cut(run, {**cut, "cut_id": "c2", "as_of": "2026-11-25T13:00:00Z"}))
        self.assertEqual(self.store.read_cut(run)["cut_id"], "c2")
        self.assertIsNotNone(self.store.read_cut(run)["published_at"])


if __name__ == "__main__":
    unittest.main()
