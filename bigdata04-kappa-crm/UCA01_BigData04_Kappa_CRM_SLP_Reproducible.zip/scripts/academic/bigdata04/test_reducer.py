"""Deterministic oracles for event attribution, state, decisions and export."""

import json
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from uuid import NAMESPACE_URL, uuid5

from contracts import Validator, load_catalog
from policy import evaluate, fixture, stamp
from reducer import reduce_events


RUN = "run-projection-oracle"
AT = datetime(2026, 11, 25, 23, 59, 59, tzinfo=timezone.utc)
CATALOG = load_catalog()
VALIDATOR = Validator(CATALOG)


def event(sequence, event_type, seconds=0, actor=0, session=0, **fields):
    return VALIDATOR.event({"event_id": str(uuid5(NAMESPACE_URL, f"{RUN}/{actor}/{sequence}")),
                            "event_type": event_type, "event_time": stamp(AT + timedelta(seconds=seconds)),
                            "simulation_run_id": RUN, "demo_actor_id": f"actor-{actor}",
                            "session_id": f"session-{actor}-{session}", "profile_id": "explorador-natural",
                            "schema_version": 1, "synthetic": True, "source": "simulator",
                            "event_sequence": sequence, **fields})


def project(events=(), controls=(), at=AT):
    return reduce_events(events, CATALOG, controls, at, RUN)


class ProjectionTest(unittest.TestCase):
    def test_route_and_favorite_tombstones_survive_replay(self):
        events = [event(1, "destination_added", route_id="route-0-0", destination_id="H07"),
                  event(2, "destination_added", route_id="route-0-0", destination_id="H06"),
                  event(3, "destination_removed", route_id="route-0-0", destination_id="H07"),
                  event(4, "favorite_added", destination_id="H07"),
                  event(5, "favorite_removed", destination_id="H07", session=1),
                  event(6, "favorite_added", destination_id="H07", session=1),
                  event(1, "favorite_removed", destination_id="H07", actor=1)]
        ordered = project(events)
        arrivals = [*reversed(events), {**events[0], "received_at": stamp(AT + timedelta(hours=3)), "offset": 44}]
        replayed = project(arrivals)
        self.assertEqual(ordered["hashes"], replayed["hashes"])
        self.assertEqual(ordered["metrics"]["state_totals"], {
            "routes": {"adds": 2, "removes": 1, "active": 1},
            "favorites": {"adds": 2, "removes": 2, "active": 1},
        })
        self.assertEqual({row["destination_id"]: row["active"] for row in ordered["tables"]["route_state"]},
                         {"H06": True, "H07": False})
        self.assertEqual({row["demo_actor_id"]: row["active"] for row in ordered["tables"]["favorite_state"]},
                         {"actor-0": True, "actor-1": False})

    def test_ctr_reconciles_late_transport_and_utc_window(self):
        base = {"destination_id": "H07", "campaign_id": "camp-agua"}
        first = event(1, "campaign_impression", impression_id="imp-0-1", visible_fraction=.5, visible_ms=1_000, **base)
        second = event(2, "campaign_impression", impression_id="imp-0-2", visible_fraction=1, visible_ms=1_200, **base)
        below = event(3, "campaign_impression", impression_id="imp-0-3", visible_fraction=.5, visible_ms=999, **base)
        clicks = [event(4, "campaign_click", 5, impression_id="imp-0-1", **base),
                  event(5, "campaign_click", 6, impression_id="imp-0-1", **base),
                  event(1, "campaign_click", 5, actor=1, impression_id="imp-0-2", **base),
                  event(6, "destination_click", 6, impression_id="imp-0-2", **base),
                  event(7, "campaign_click", -1, impression_id="imp-0-2", **base),
                  event(8, "campaign_click", 6, impression_id="imp-0-3", **base),
                  event(9, "campaign_click", 6, impression_id="imp-0-9", **base),
                  event(10, "campaign_click", 6, session=1, impression_id="imp-0-2", **base)]
        partial = project(clicks)
        self.assertTrue(all(row["ctr_pct"] is None for row in partial["tables"]["ctr_daily"]))
        complete = project([*clicks, first, below, second])
        self.assertEqual(complete["hashes"], project([second, below, first, *reversed(clicks)])["hashes"])
        row = next(row for row in complete["tables"]["ctr_daily"]
                   if row["family"] == "campaign" and row["day_utc"] == "2026-11-25")
        self.assertEqual((row["eligible_impressions"], row["clicked_impressions"], row["eligible_click_actions"], row["ctr_pct"]),
                         (2, 1, 2, 50))
        quality = complete["metrics"]["quality"]
        self.assertEqual(quality["click_mismatched_impression"], 3)
        self.assertEqual(quality["click_before_impression"], 1)
        self.assertEqual(quality["click_below_visibility_threshold"], 1)
        self.assertEqual(quality["click_missing_impression"], 1)

    def test_recommendation_count_shares_single_route_mutation(self):
        events = [event(1, "recommendation_seen", place_ids=["H07", "H06"], surface="route"),
                  event(2, "recommendation_added", destination_id="H06", route_id="route-0-0"),
                  event(3, "destination_added", destination_id="H06", route_id="route-0-0"),
                  event(4, "category_selected", selected=True, interest="agua"),
                  event(5, "category_selected", selected=False, interest="agua"),
                  event(6, "route_generated", route_id="route-0-0", stops=1)]
        result = project(events)
        summary = result["metrics"]
        self.assertEqual(summary["recommendations"], {"lists": 1, "items_shown": 2, "saved_actions": 1})
        self.assertEqual(summary["state_totals"]["routes"], {"adds": 1, "removes": 0, "active": 1})
        self.assertEqual(next(row for row in summary["profiles"] if row["profile_id"] == "explorador-natural")["routes_generated"], 1)
        self.assertEqual(next(row for row in summary["interests"] if row["interest"] == "agua"),
                         {"interest": "agua", "selected": 1, "deselected": 1})

    def test_impression_key_reuse_and_identity_conflict_are_audited(self):
        fields = {"impression_id": "imp-0-1", "destination_id": "H07", "visible_fraction": 1, "visible_ms": 1_000}
        originals = [event(1, "destination_impression", **fields), event(2, "destination_impression", **fields),
                     event(3, "destination_click", destination_id="H07", impression_id="imp-0-1"),
                     event(4, "favorite_added", destination_id="H07")]
        conflict = {**originals[-1], "destination_id": "H06"}
        result = project([*originals, conflict])
        self.assertEqual(result["hashes"], project([conflict, *reversed(originals)])["hashes"])
        self.assertEqual(result["metrics"]["quality"]["ambiguous_impression_ids"], 1)
        self.assertEqual(result["metrics"]["quality"]["click_ambiguous_impression"], 1)
        self.assertEqual(result["metrics"]["quality"]["canonical_id_conflicts"], 1)
        self.assertEqual(result["tables"]["favorite_state"], [])

    def test_cases_a_to_d_and_expired_newer_revision(self):
        initial = fixture(RUN, "initial", AT)
        change = fixture(RUN, "change", AT + timedelta(minutes=1))[0]
        change["valid_to"] = stamp(AT + timedelta(minutes=3))
        clicks = [event(i, "campaign_click", impression_id="imp-0-1", campaign_id="camp-agua", destination_id="H07")
                  for i in range(1, 10)]
        before = project(clicks, [*initial, change], AT)
        outcome = {row["destination_id"]: row for row in before["tables"]["decisions"]}
        self.assertEqual((outcome["H07"]["status"], outcome["H07"]["digital_click_actions"]), ("pausa", 9))
        self.assertEqual(outcome["H06"]["status"], "candidato")
        self.assertEqual(outcome["A01"]["status"], "sin_datos")
        after = project(clicks, [*initial, change], AT + timedelta(minutes=2))
        d = next(row for row in after["tables"]["decisions"] if row["destination_id"] == "H06")
        self.assertEqual((d["case"], d["revision"], d["status"], d["reason"], d["automatic_increase"]),
                         ("D", 2, "pausa", "cupo_insuficiente", False))
        self.assertEqual([row["trigger_case"] for row in after["tables"]["decision_history"] if row["destination_id"] == "H06"], ["B", "D"])
        expired = evaluate("H06", [initial[1], change], AT + timedelta(minutes=4))
        self.assertEqual((expired["status"], expired["revision"], expired["reason"]), ("bloqueado", 2, "revision_fuera_de_vigencia"))
        alert = evaluate("H06", [{**initial[1], "environmental_status": "alert"}], AT)
        self.assertEqual((alert["status"], alert["reason"]), ("pausa", "alerta_ambiental"))

    def test_mixed_runs_are_rejected(self):
        mixed = {**event(1, "destination_view", destination_id="H07"), "simulation_run_id": "run-other"}
        with self.assertRaisesRegex(ValueError, "otra corrida"):
            project([mixed])

    def test_parquet_duckdb_and_hashes_are_verified(self):
        import duckdb
        from export import publish, verify_manifest

        ledger = [event(1, "destination_view", destination_id="H06"),
                  event(2, "campaign_impression", campaign_id="camp-agua", impression_id="imp-0-0",
                        visible_ms=1_000, visible_fraction=.52),
                  event(3, "campaign_click", campaign_id="camp-agua", impression_id="imp-0-0"),
                  event(4, "destination_added", destination_id="H06", route_id="route-0-0")]
        snapshot = {"events": ledger, "controls": fixture(RUN, "initial", AT), "positions": {"0": 4},
                    "audit": {"counts": {"new": 4, "conflict": 0}}}
        with tempfile.TemporaryDirectory() as out:
            manifest = publish(snapshot, CATALOG, RUN, out, AT, 42)
            folder = Path(out) / RUN / manifest["cut_id"]
            self.assertEqual(verify_manifest(folder / "manifest.json"), manifest)
            self.assertEqual(publish(snapshot, CATALOG, RUN, out, AT, 42), manifest)
            with duckdb.connect(str(folder / "crm.duckdb"), read_only=True) as db:
                self.assertEqual(db.execute("SELECT ctr_pct FROM campaign_summary WHERE campaign_id='camp-agua'").fetchone(), (100.0,))
                self.assertEqual(db.execute("SELECT active_elements FROM state_summary WHERE entity='routes'").fetchone(), (1,))
                self.assertEqual(db.execute("SELECT count(*) FROM decision_history").fetchone(), (2,))
            indicator = json.loads((folder / "indicators.json").read_text(encoding="utf-8"))
            self.assertFalse(indicator["history"]["available"])
            self.assertEqual(indicator["hashes"]["results"], manifest["hashes"]["results"])
            for field, key in (("files", "crm.duckdb"), ("files", "indicators.json"), ("tables", "controls")):
                modified = json.loads(json.dumps(manifest))
                del modified[field][key]
                (folder / "manifest.json").write_text(json.dumps(modified), encoding="utf-8")
                with self.assertRaises(ValueError):
                    verify_manifest(folder / "manifest.json")
            modified = json.loads(json.dumps(manifest))
            modified["tables"]["events"]["schema"]["event_id"] = "int32"
            (folder / "manifest.json").write_text(json.dumps(modified), encoding="utf-8")
            with self.assertRaises(ValueError):
                verify_manifest(folder / "manifest.json")


if __name__ == "__main__":
    unittest.main()
